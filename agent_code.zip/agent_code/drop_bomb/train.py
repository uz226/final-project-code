import pickle
import random
from collections import namedtuple, deque
from typing import List
import numpy as np

import events as e
from .callbacks import state_to_features

# This is only an example!
Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))

# Hyper parameters -- DO modify
GAMMA = 0.9
ALPHA = 0.7
# Events
PLACEHOLDER_EVENT = "PLACEHOLDER"
CLOSER = "CLOSER"
SURVIVED_STEP = "SURVIVED_STEP"
EXPLOSION = "EXPLOSION"

### DICTIONARY FOR ACTIONS INDICES ################################################
act_dict = {}
act_dict['UP'] = 0
act_dict['RIGHT'] = 1
act_dict['DOWN'] = 2
act_dict['LEFT'] = 3
act_dict['WAIT'] = 4

########### ROTATION TABLE #####################################################

rot0 = np.array([0, 1, 2, 3])
rot1 = np.array([1, 3, 0, 2])
rot2 = np.array([3, 2, 1, 0])
rot3 = np.array([2, 0, 3, 1])
back_rot = np.vstack((rot0, rot1, rot2, rot3))




###############################################################


def setup_training(self):
    """
    Initialise self for training purpose.

    This is called after `setup` in callbacks.py.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    # Example: Setup an array that will note transition tuples
    # (s, a, r, s')
    #self.transitions = deque(maxlen=TRANSITION_HISTORY_SIZE)

    self.bomb = np.zeros((2*, 5))
    # 0 = UP
    # 1 = RIGHT
    # 2 = DOWN
    # 3 = LEFT
    # 4 = WAIT
    self.bomb_counts = []
    self.bomb_counter = 0

def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: List[str]):
    """
    Called once per step to allow intermediate rewards based on game events.

    When this method is called, self.events will contain a list of all game
    events relevant to your agent that occurred during the previous step. Consult
    settings.py to see what events are tracked. You can hand out rewards to your
    agent based on these events and your knowledge of the (new) game state.

    This is *one* of the places where you could update your agent.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    :param old_game_state: The state that was passed to the last call of `act`.
    :param self_action: The action that you took.
    :param new_game_state: The state the agent is in now.
    :param events: The events that occurred when going from  `old_game_state` to `new_game_state`
    """
    self.logger.debug(f'Encountered game event(s) {", ".join(map(repr, events))} in step {new_game_state["step"]}')

    # Idea: Add your own events to hand out rewards
    if old_game_state is None:
        return
    if old_game_state['self'][2]:
        return
    if self_action == 'BOMB_DROPPED': # bomb counter
        self.bomb_counter += 1


def end_of_round(self, last_game_state: dict, last_action: str, events: List[str]):
    """
    Called at the end of each game or when the agent died to hand out final rewards.

    This is similar to reward_update. self.events will contain all events that
    occurred during your agent's final step.

    This is *one* of the places where you could update your agent.
    This is also a good place to store an agent that you updated.

    :param self: The same object that is passed to all of your callbacks.
    """
    self.logger.debug(f'Encountered event(s) {", ".join(map(repr, events))} in final step')
    #self.transitions.append(Transition(state_to_features(last_game_state), last_action, None, reward_from_events(self, events)))

    # Store the model
    with open("bomb-model.pt", "wb") as file:
        pickle.dump(self.bomb, file)
    self.bomb_counts.append(self.bomb_counter)
    with open('bomb_counts.pt', 'wb') as file:
        pickle.dump(self.bomb_counts, file)
    self.bomb_counter = 0

def reward_from_events(self, events: List[str]) -> int:
    """
    *This is not a required function, but an idea to structure your code.*

    Here you can modify the rewards your agent get so as to en/discourage
    certain behavior.
    """
    game_rewards = {

        e.KILLED_OPPONENT: 5,
        PLACEHOLDER_EVENT: -.1,  # idea: the custom event is bad
        CLOSER: 0.5,
        e.INVALID_ACTION: -10,
        e.KILLED_SELF: -100,
        SURVIVED_STEP: 0.1,
        EXPLOSION: -5
    }
    reward_sum = 0
    for event in events:
        if event in game_rewards:
            reward_sum += game_rewards[event]
    self.logger.info(f"Awarded {reward_sum} for events {', '.join(events)}")
    return reward_sum

import os
import pickle
import random

import numpy as np


ACTIONS = np.array(['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB'])


EPSILON = 1
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.001

########### ROTATION TABLE #####################################################

rot0 = np.array([0,1,2,3,4])
rot1 = np.array([1,3,0,2,4])
rot2 = np.array([3,2,1,0,4])
rot3 = np.array([2,0,3,1,4])
back_rot = np.vstack((rot0, rot1, rot2, rot3))

corners = np.array([[1,1], [15,15], [1,15], [15,1]])

def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    if self.train:
        # if self.train and not os.path.isfile("movin-model.pt"):
        with open("../avoid_stones/q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)
        with open("../avoid_stones/q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)

    else:
        self.logger.info("Loading model from saved state.")
        with open("bomb-model.pt", "rb") as file:
            self.bomb = pickle.load(file)
        with open("../avoid_stones/q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)

def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """
    # todo Exploration vs exploitation
    #EPSILON = 0.4

    rot = state_to_features_avoid(game_state)[1]
    action_rot = np.where(self.avoid_stones[state_to_features_avoid(game_state)[0], :] >= 0)[0]
    best_indices = []
    # action_rot = np.array([action_rot])
    for x in action_rot:
        a = (x + rot) % 4
        best_indices.append(a)
    best_indices.append(4)
    self.logger.debug("Best Actions: {}".format(best_indices))
    if self.train:
        self.logger.debug("TRAINING PATH")
        self.logger.debug("BOMB ACTIVE?: {}".format(game_state['self'][2]))
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON

        # print EPSILON
        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)



        if game_state['self'][2] is False:
            table = 0
            EPSILON_THRESHOLD = random.uniform(0, 1)
            if EPSILON_THRESHOLD > EPSILON1:

                agent_position, bomb_pos, bomb_state, match_index, rot_index = state_to_features(game_state)
                bomb_index = 4 * match_index + bomb_state
                possible_action = np.copy(self.bomb[table, bomb_index, back_rot[rot_index, :]])

                possible_action[best_indices] = possible_action[best_indices] + 1000
                action_idx = np.argmax(possible_action)
                self.logger.debug('action_idx = {}'.format(action_idx))
                action = ACTIONS[action_idx]
                self.logger.info('Moving with EXPLOITATION')
                self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
                return action
            else:
                self.logger.info('MOVING RANDOMLY (EXPLORATION)')

                return np.random.choice(ACTIONS[best_indices])

        else:
            table = 1
            self.logger.info('TABLE 1')
            EPSILON_THRESHOLD = random.uniform(0, 1)
            if EPSILON_THRESHOLD > EPSILON1:
                agent_position, bomb_pos, bomb_state, match_index, rot_index = state_to_features(game_state)
                if match_index == 0:
                    if (agent_position[0] and agent_position[1]) in corners:

                        return np.random.choice(ACTIONS[best_indices[:-1]])

                    else:
                        return ACTIONS[5]

                possible_action = np.copy(self.bomb[table, match_index, back_rot[rot_index, :]])
                possible_action[best_indices] = possible_action[best_indices] + 1000
                action_idx = np.argmax(possible_action)

                action = ACTIONS[action_idx]
                self.logger.debug('action_idx = {}'.format(action_idx))

                self.logger.info('Moving with EXPLOITATION')
                self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
                return action
            else:
                self.logger.info('MOVING RANDOMLY (EXPLORATION)')


                best_indices.append(5)
                return np.random.choice(ACTIONS[best_indices])




    else:
        self.logger.info('NON training path')
        if game_state['self'][2] is False:
            self.logger.info('Game_state is false')
            table = 0
            agent_position, bomb_pos, bomb_state, match_index, rot_index = state_to_features(game_state)
            self.logger.info('Called state_to_feature')
            self.logger.debug('match_index = {}'.format(match_index))
            if match_index == 0:
                if (agent_position[0] and agent_position[1]) in corners:

                    return np.random.choice(ACTIONS[best_indices[:-1]])
                else:
                    return ACTIONS[5]

            bomb_index = 4 * match_index + bomb_state

            possible_action = np.copy(self.bomb[table, bomb_index, back_rot[rot_index, :]])
            possible_action[best_indices] = possible_action[best_indices] + 1000
            action_idx = np.argmax(possible_action)
            self.logger.info('Set up bomb_index, action_index')
            self.logger.debug('action_index = {}'.format(action_idx))
            self.logger.debug('rot_index = {}'.format(rot_index))

            action = ACTIONS[action_idx]

            self.logger.info('Moving with MODEL')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action
        else:
            self.logger.info('Game_state is true')
            table = 1
            agent_position, bomb_pos, bomb_state, match_index, rot_index = state_to_features(game_state)
            self.logger.info('Called state_to_feature')
            self.logger.debug('match_index = {}'.format(match_index))
            if match_index == 0:
                if (agent_position[0] and agent_position[1]) in corners:
                    return np.random.choice(ACTIONS[best_indices[:-1]])

                else:
                    return ACTIONS[5]
            else:
                possible_action = np.copy(self.bomb[table, match_index, back_rot[rot_index, :]])
                possible_action[best_indices] = possible_action[best_indices] + 1000
                action_idx = np.argmax(possible_action)
                self.logger.info('Got action_index')
                action = ACTIONS[action_idx]
                self.logger.info('Moving with EXPLOITATION')
                self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
                return action




#### DEFINITION STATES ############################################################

surround_states = [np.zeros((2, 2))     ,
                   np.array([[1, 0],
                             [0, 0]]) ,
                   np.array([[1, 1],
                             [0, 0]]) ,
                   np.array([[1, 0],
                             [0, 1]]) ,
                   np.array([[1, 1],
                             [0, 1]]) ,
                   np.array([[1, 1],
                             [1, 1]]),
                '''np.array([[1, -1],
                             [-1, 0]]),
                   np.array([[-1, -1],
                             [0, 0]]) ,
                   np.array([[-1, -1],
                             [1, 0]]) ,
                   np.array([[1, -1],
                             [-1, 0]])'''

                    ]

########## DEF FIND_MATCH FUNCTION ##############################
def find_match(A):
    size = len(surround_states)
    match_index = 0
    i = 0
    r = 0
    a = True
    while a == True and i < size:
        #print(i)
        if np.all(A == surround_states[i]) == True:
            match_index = i
            r = 0
            a = False
        i += 1

    j = 0
    while a == True and j < size:
        #print(j)
        B = np.rot90(A, k=1)
        if np.all(B == surround_states[j]) == True:
            match_index = j
            r = 1
            a = False
        j += 1

    k = 0
    while a == True and k < size:
        #print(k)
        C = np.rot90(A, k=2)
        if np.all(C == surround_states[k]) == True:
            match_index = k
            r = 2
            a = False
        k += 1

    l = 0
    while a == True and l < size:
        #print(l)
        D = np.rot90(A, k=3)
        if np.all(D == surround_states[l]) == True:
            match_index = l
            r = 3
            a = False
        l += 1
    return match_index, r

####### IS IN BOMB RANGE ##########################################################################

def is_in_bomb_range(bomb, surround_pos):
    check = bomb == surround_pos
    in_range = []
    for j in range(np.shape(surround_pos)[0]):

        idx = np.where(check[j] == False)[0]
        distance = np.abs(bomb[idx] - surround_pos[j, idx])
        if np.shape(idx)[0] == 1 and distance < 4:
            in_range.append(1)

        if np.shape(idx)[0] == 1 and distance > 3:

            in_range.append(0)

        elif np.shape(idx)[0] == 0:

            in_range.append(1)

        elif np.shape(idx)[0] == 2:

            in_range.append(0)

    return np.array(in_range).reshape(2, 2)

### ACTION DICTIONARY ####################################################################

action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

##########################################################################################




def state_to_features(game_state: dict) -> np.array:
    """
    *This is not a required function, but an idea to structure your code.*

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """

    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    ### GET THE OPERATIONS IN COORDS #########################################
    field = game_state["field"]
    agent_pos = np.array(game_state['self'][3])

    above = agent_pos + np.array(action_dict["UP"])
    below = agent_pos + np.array(action_dict["DOWN"])
    right_side = agent_pos + np.array(action_dict["RIGHT"])
    left_side = agent_pos + np.array(action_dict["LEFT"])
    surroundings = np.array([left_side, above, below, right_side])

    # matrix for the fields surrounding the agent
    # [ left, above ]
    # [ below, right]

    #['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
    surround_agent = np.zeros((2, 2))
    surround_agent[1, 1] = field[left_side[0], left_side[1]]
    surround_agent[0, 1] = field[right_side[0], right_side[1]]
    surround_agent[0, 0] = field[above[0], above[1]]
    surround_agent[1, 0] = field[below[0], below[1]]


    channels = []
    channels.append(agent_pos)

    ### Case: Bomb is dropped #############################################
    if game_state['self'][2] is False:

        bomb_pos = np.array(game_state['bombs'][0][0])
        bomb_state = game_state['bombs'][0][1]

        bomb_field_surround = is_in_bomb_range(bomb_pos, surroundings)
        whole_field = surround_agent + bomb_field_surround
        relevant_bomb_fields = np.zeros((2, 2))
        relevant_bomb_fields[np.where(whole_field == 1)] = 1
        #print('BOMBField matrix: {}'.format(relevant_bomb_fields))
        channels.append(bomb_pos)
        channels.append(bomb_state)

        ### finding matching surroundings to the agent ##################################
        match_index, rot_index = find_match(relevant_bomb_fields)
        channels.append(match_index)
        channels.append(rot_index)


    ### Case: no bomb, but check for explosionfields around
    else:
        explosion_map = game_state['explosion_map']

        bomb_pos = None
        bomb_state = None
        channels.append(bomb_pos)
        channels.append(bomb_state)

        flames_surround_agent = np.zeros((2, 2))
        flames_surround_agent[1, 1] = explosion_map[left_side[0], left_side[1]]
        flames_surround_agent[0, 0] = explosion_map[above[0], above[1]]
        flames_surround_agent[1, 0] = explosion_map[below[0], below[1]]
        flames_surround_agent[0, 1] = explosion_map[right_side[0], right_side[1]]
        flames_surround_agent[np.where(flames_surround_agent == 2)] = 1
        match_index, rot_index = find_match(flames_surround_agent)



        channels.append(match_index)
        channels.append(rot_index)

    return channels

def state_to_features_avoid(game_state: dict) -> np.array:
    """
    This is not a required function, but an idea to structure your code.

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    # 4 possibilities for the stones and crates surrounding our agent
    field = game_state["field"]
    agent_pos = game_state["self"][3]

    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    above = np.array(agent_pos) + np.array(action_dict["UP"])
    below = np.array(agent_pos) + np.array(action_dict["DOWN"])
    right_side = np.array(agent_pos) + np.array(action_dict["RIGHT"])
    left_side = np.array(agent_pos) + np.array(action_dict["LEFT"])

    surrounding = np.array([field[left_side[0]][left_side[1]], field[above[0]] [above[1]],
                        field[right_side[0]][right_side[1]], field[below[0]] [below[1]]])

    # find stone_position
    locked_ways = np.count_nonzero(np.abs(surrounding) == 1)
    #print("locked_ways", locked_ways)
    stone_state = locked_ways
    rot = 0

    #print("stone_state", stone_state)
    # find rotation
    #normed_states = [np.array([[0,0],[0, 0]]), np.array([[1, 0], [0, 0]]), np.array([[1, 1], [0, 0]]), np.array([[0, 1], [1, 1]]), np.array([[1, 0], [0, 1]]])
    if stone_state == 0:
        rot = 0
    elif stone_state == 1:
        rot = np.where(np.abs(surrounding) == 1)[0][0]
    elif stone_state == 2:
        a, b = np.where(np.abs(surrounding) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
        elif a == 1 and b == 2:
            rot = 1
        elif a == 2 and b == 3:
            rot = 2
        elif a == 0 and b == 3:
            rot = 3
        elif a == 0 and b == 2:
            rot = 0
            stone_state = 4
        elif a == 1 and b == 3:
            rot = 1
            stone_state = 4

    elif stone_state == 3:
        rot = np.where(np.abs(surrounding) == 0)[0][0]

    #print("surrounding", surrounding, "stone_state", stone_state, "rot", rot)

    channels = []
    channels.append(stone_state)
    channels.append(rot)

    return channels
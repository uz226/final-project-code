import os
import pickle
import random

import numpy as np


EPSILON = 0.4  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.01
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
forbidden = np.arange(14)[1::2]

def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """

    if self.train:
    #if self.train and not os.path.isfile("movin-model.pt"):
        pass

    else:
        self.logger.info("Loading model from saved state.")
        with open("../Saves/q-model.pt", "rb") as file:
            self.q = pickle.load(file)


def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """
    state, direc = state_to_features(game_state)
    if self.train:
        '''
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON
        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)'''
        EPSILON1 = EPSILON
        # todo Exploration vs exploitation
        EPSILON_THRESHOLD = random.uniform(0, 1)
        if EPSILON_THRESHOLD > EPSILON1:

            action_idx = np.argmax(self.q[direc, state, :4])
            action = ACTIONS[action_idx]  #state_to_features(game_state)[action_idx+1]
            self.logger.info('Moving with EXPLOITATION')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action

        else:
            self.logger.debug("Querying model for action.")
            self.logger.info('Moving with EXPLORATION')
            return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])

        #if (xy) + action = Kasten:
        #    choose left/right bzw up/down
    else:
        '''
        if game_state['step'] == 1:
            return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])
        else:'''
        action_idx = np.argmax(self.q[direc, state, :4])
        action = ACTIONS[action_idx]  #state_to_features(game_state)[action_idx + 1]
        self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
        return action

'''if len(action) > 1:
            return np.random.choice(action)
        else:
            return action[0]'''

'''def action_to_coord(game_state, action):
    agent_pos = np.array(game_state['self'][3])
    act_dict = {}
    act_dict['UP'] = np.array([1, 0])
    act_dict['DOWN'] = np.array([-1, 0])
    act_dict['RIGHT'] = np.array([0, 1])
    act_dict['LEFT'] = np.array([0, -1])
    directions = np.array([act_dict[action[0]], act_dict[action[1]]])
    new_positions = agent_pos + directions
    return new_positions'''


def state_to_features(game_state: dict) -> np.array:
    """
    This is not a required function, but an idea to structure your code.

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    agent_position = np.array(game_state["self"][3])
    coins = np.array(game_state["coins"])

    nearest_coin = np.argmin(np.sum(np.abs(coins-agent_position), axis = 1))
    distance = np.sum(np.abs(coins[nearest_coin]-agent_position))
    dist_lu = 0
    dist_ld = 1
    dist_ru = 2
    dist_rd = 3
    dist_u = 4
    dist_r = 5
    dist_l = 6
    dist_d = 7

    dist = coins[nearest_coin] - agent_position
    direction = 0
    if np.all(dist < 0):
        direction = 0
    elif np.all(dist > 0):
        direction = 3


    if dist[0] > 0 and dist[1] < 0:
        direction = 2

    elif dist[0] < 0 and dist[1] > 0:
        direction = 1

    if dist[0] == 0 and dist[1] < 0:
        direction = 4
    elif dist[0] == 0 and dist[1] > 0:
        direction = 7

    if dist[1] == 0 and dist[0] < 0:
        direction = 6
    elif dist[1] == 0 and dist[0] > 0:
        direction = 5
    # For example, you could construct several channels of equal shape, ...
    channels = []
    channels.append(distance)
    channels.append(direction)
    # concatenate them as a feature tensor (they must have the same shape), ...
    #stacked_channels = np.stack(channels)
    # and return them as a vector

    return channels




    #coin_pos = new_game_state['coins']
    #my_pos = new_game_state['self'][3]
    #closest_coin_idx = np.argmin(np.sum(np.abs(coin_pos - my_pos)))
    #closest_coin = coin_pos[closest_coin_idx]
import pickle
import random
from collections import namedtuple, deque
from typing import List
import numpy as np
import os

import events as e
from .callbacks import state_to_features


# Hyper parameters -- DO modify
GAMMA = 0.8
ALPHA = 0.6
# Events

EXPLOSION = "EXPLOSION"

### DICTIONARY FOR ACTIONS INDICES ################################################
act_dict = {}
act_dict['UP'] = 0
act_dict['RIGHT'] = 1
act_dict['DOWN'] = 2
act_dict['LEFT'] = 3
act_dict['WAIT'] = 4
act_dict["BOMB"] = 5

########### ROTATION TABLE #####################################################
"""
rot0 = np.array([0, 1, 2, 3, 4])
rot1 = np.array([1, 3, 0, 2, 4])
rot2 = np.array([3, 2, 1, 0, 4])
rot3 = np.array([2, 0, 3, 1, 4])
"""
rot0 = np.array([0, 1, 2, 3, 4])
rot1 = np.array([3, 0, 1, 2, 4])
rot2 = np.array([2, 3, 0, 1, 4])
rot3 = np.array([1, 2, 3, 0, 4])
back_rot = np.vstack((rot0, rot1, rot2, rot3))




###############################################################


def setup_training(self):
    """
    Initialise self for training purpose.

    This is called after `setup` in callbacks.py.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    # Example: Setup an array that will note transition tuples
    # (s, a, r, s')
    #self.transitions = deque(maxlen=TRANSITION_HISTORY_SIZE)
    if os.path.isfile("bomb-model.pt"):
    #if False:
        with open("bomb-model.pt", "rb") as file:
            self.bomb = pickle.load(file)
        print("file loaded")

    else:
        #self.bomb = np.zeros((2*4*19+6, 5))
        self.bomb = np.zeros((48, 5))
        # 0 = UP
        # 1 = RIGHT
        # 2 = DOWN
        # 3 = LEFT
        # 4 = WAIT
    self.bomb_counts = []
    self.bomb_counter = 0
    self.step_counts = []

def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: List[str]):
    """
    Called once per step to allow intermediate rewards based on game events.

    When this method is called, self.events will contain a list of all game
    events relevant to your agent that occurred during the previous step. Consult
    settings.py to see what events are tracked. You can hand out rewards to your
    agent based on these events and your knowledge of the (new) game state.

    This is *one* of the places where you could update your agent.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    :param old_game_state: The state that was passed to the last call of `act`.
    :param self_action: The action that you took.
    :param new_game_state: The state the agent is in now.
    :param events: The events that occurred when going from  `old_game_state` to `new_game_state`
    """
    self.logger.debug(f'Encountered game event(s) {", ".join(map(repr, events))} in step {new_game_state["step"]}')


    if old_game_state is None:
        return

    if self_action == 'BOMB': # bomb counter
        self.bomb_counter += 1
        return

    self.logger.debug("features = {}".format(state_to_features(old_game_state)))
    ### loading state_to_features ###################################################

    agent_pos, bomb_info, state_info = state_to_features(old_game_state)
    agent_pos_new, bomb_info_new, state_info_new  = state_to_features(new_game_state)

    bomb_pos, bomb_state, bomb_fields, dead_end = bomb_info
    bomb_pos_new, bomb_state_new, bomb_fields_new, dead_end_new = bomb_info_new

    state, rot_index, on_bomb_field, old_surround, state_surround = state_info
    state_new, rot_index_new, on_bomb_field_new, new_surround, new_state_surround = state_info_new

    """
    distance = 0
    relative_distance = 0
    not_dead_end_direction = -1
    if bomb_state is not None:
        relative_distance = np.sum(np.abs(agent_pos_new-bomb_pos)) - np.sum(np.abs(agent_pos-bomb_pos))
        distance = np.sum(np.abs(agent_pos_new-bomb_pos))
    if np.isin(act_dict[self_action], np.where(dead_end == 0)):
        not_dead_end_direction = 1
    if self_action == 'WAIT' and np.sum(dead_end) == 20:
        not_dead_end_direction = 1
    if on_bomb_field_new == 1:
        bomb_state_new = 5

    field_reward = -5 + (-4 + bomb_state_new) + distance + not_dead_end_direction + relative_distance
    """

    #self.logger.debug("distance = {}".format(distance))
    #self.logger.debug("bomb_field_reward = {}".format(field_reward))

    field_reward = 0
    if on_bomb_field_new == 1:
        field_reward = 10

    else:
        field_reward = -10

    if agent_pos[0] == agent_pos_new[0] and agent_pos[1] == agent_pos_new[1]:
        field_reward += -5

    ### back rotating the action ####################################################
    made_action = act_dict[self_action]  # rotated action surround_agent
    if made_action != 4:
        back_rotated_action = back_rot[rot_index, made_action]
    else:
        back_rotated_action = made_action

    """
    print("surround", old_surround)
    print("state", state_surround, rot_index, state)
    print("action", self_action)
    print("back_rotated_action", back_rotated_action)
    print("reward", field_reward)
    print("old_value", self.bomb[state, back_rotated_action])
    """

    ### updating Q-function #########################################################
    self.bomb[state, back_rotated_action] = self.bomb[state, back_rotated_action] * (1 - ALPHA) + ALPHA * (field_reward +
                                            GAMMA * np.max(self.bomb[state_new, :]))

    #print("new_value", self.bomb[state, back_rotated_action])
    #print("")

def end_of_round(self, last_game_state: dict, last_action: str, events: List[str]):
    """
    Called at the end of each game or when the agent died to hand out final rewards.

    This is similar to reward_update. self.events will contain all events that
    occurred during your agent's final step.

    This is *one* of the places where you could update your agent.
    This is also a good place to store an agent that you updated.

    :param self: The same object that is passed to all of your callbacks.
    """
    if last_game_state['step'] != 400:
        reward = -25
        agent_pos, bomb_info, state_info = state_to_features(last_game_state)
        state, rot_index, on_bomb_field, surround, state_surround = state_info

        made_action = act_dict[last_action]  # rotated action surround_agent
        if made_action <= 4:
            back_rotated_action = back_rot[rot_index, made_action]
        else:
            back_rotated_action = made_action
        self.logger.debug('Last action: {}'.format(back_rotated_action))

        """
        print("last", surround)
        print("state", state_surround, rot_index, state)
        print("action", last_action)
        print("back_rotated_action", back_rotated_action)
        print("reward", reward)
        print("old_value", self.bomb[state, back_rotated_action])
        """

        ### updating Q-function #########################################################
        self.bomb[state, back_rotated_action] = self.bomb[state, back_rotated_action] * (1 - ALPHA) + ALPHA * reward

        #print("new_value", self.bomb[state, back_rotated_action])
        #print("")
        #print("")
       # print("")

    self.logger.debug(f'Encountered event(s) {", ".join(map(repr, events))} in final step')
    #self.transitions.append(Transition(state_to_features(last_game_state), last_action, None, reward_from_events(self, events)))

    # Store the model
    with open("bomb-model.pt", "wb") as file:
        pickle.dump(self.bomb, file)
    self.bomb_counts.append(self.bomb_counter)
    with open('bomb_counts.pt', 'wb') as file:
        pickle.dump(self.bomb_counts, file)
    self.bomb_counter = 0
    self.step_counts.append(last_game_state['step'])
    with open("step_counts.pt", "wb") as file:
        pickle.dump(self.step_counts, file)


def reward_from_events(self, events: List[str]) -> int:
    """
    *This is not a required function, but an idea to structure your code.*

    Here you can modify the rewards your agent get so as to en/discourage
    certain behavior.
    """
    game_rewards = {

        e.KILLED_OPPONENT: 5,

        e.INVALID_ACTION: -10,
        e.KILLED_SELF: -10,

        EXPLOSION: -5
    }
    reward_sum = 0
    for event in events:
        if event in game_rewards:
            reward_sum += game_rewards[event]
    self.logger.info(f"Awarded {reward_sum} for events {', '.join(events)}")
    return reward_sum

import os
import pickle
import random

import numpy as np


EPSILON = 1  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.001
ACTIONS = ['LEFT', 'UP', 'RIGHT', 'DOWN', 'WAIT', 'BOMB'] # !!!!


def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """

    if self.train:
    #if self.train and not os.path.isfile("q-avoid_stones.pt"):
        pass

    else:
        self.logger.info("Loading model from saved state.")
        with open("q-avoid_stones.pt", "rb") as file:
            self.q = pickle.load(file)


def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """

    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON

        # print EPSILON
        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)

        # todo Exploration vs exploitation
        EPSILON_THRESHOLD = random.uniform(0, 1)
        if EPSILON_THRESHOLD > EPSILON1:
            # choose action with highest value in q-table
            best_actions_idx = np.where(self.q[state_to_features(game_state)[0], :] != 0)[0]
            action = ACTIONS[np.random.choice(best_actions_idx)]
            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action

        else:
            self.logger.debug("Querying model for action.")
            self.logger.info('Moving with Exploration')
            return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])

    else:
        #print(game_state['explosion_map'])
        if game_state['step'] is None:
            return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])
        else:
            # choose action with highest value in q-table
            best_actions_idx = np.where(self.q[state_to_features(game_state)[0], :] != 0)[0]
            action = ACTIONS[np.random.choice(best_actions_idx)]
            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action


def state_to_features(game_state: dict) -> np.array:
    """
    This is not a required function, but an idea to structure your code.

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    # 11 possibilities for the stones surrounding our agent
    field = game_state["field"]
    agent_pos = game_state["self"][3]

    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    above = np.array(agent_pos) + np.array(action_dict["UP"])
    below = np.array(agent_pos) + np.array(action_dict["DOWN"])
    right_side = np.array(agent_pos) + np.array(action_dict["RIGHT"])
    left_side = np.array(agent_pos) + np.array(action_dict["LEFT"])

    # corner up, left
    if field[above[0]] [above[1]] == -1 and field[left_side[0]] [left_side[1]] == -1:
        stones_case = 0
    # corner up, right
    elif field[above[0]] [above[1]] == -1 and field[right_side[0]] [right_side[1]] == -1:
        stones_case = 1
    # corner down, right
    elif field[below[0]] [below[1]] == -1 and field[right_side[0]] [right_side[1]] == -1:
        stones_case = 2
    # corner down, left
    elif field[below[0]] [below[1]] == -1 and field[left_side[0]] [left_side[1]] == -1:
        stones_case = 3

    # stones left and right
    elif field[right_side[0]] [right_side[1]] == -1 and field[left_side[0]] [left_side[1]] == -1:
        stones_case = 4
    # stones up and down
    elif field[above[0]] [above[1]] == -1 and field[below[0]] [below[1]] == -1:
        stones_case = 5

    # stones left
    elif field[left_side[0]] [left_side[1]] == -1:
        stones_case = 6
    # stones up
    elif field[above[0]] [above[1]] == -1:
        stones_case = 7
    # stones right
    elif field[right_side[0]] [right_side[1]] == -1:
        stones_case = 8
    # stones down
    elif field[below[0]] [below[1]] == -1:
        stones_case = 9

    # no stones
    else:
        stones_case = 10

    channels = []
    channels.append(stones_case)

    return channels
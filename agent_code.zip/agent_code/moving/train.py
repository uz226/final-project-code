import pickle
from collections import namedtuple
from typing import List

import events as e
from .callbacks import state_to_features
import numpy as np

GAMMA = 0.9  # discount factor
ALPHA = 0.6  # learning rate


def setup_training(self):
    """
    Initialise self for training purpose.

    This is called after `setup` in callbacks.py.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    # Create Q-List
    self.steps = []
    # self.q_list = []
    if True:
        # if not os.path.isfile("q-model.pt"):
        self.logger.info("Setting up hyperparam")
        self.q = np.zeros((11, 5))

        # a = np.copy(self.q)
        # self.q_list.append(a)

    # create action dictionary for our q list
    self.q_dict = {"LEFT": 0, "UP": 1, "RIGHT": 2, "DOWN" : 3, "WAIT" : 4}
    self.action_dict = {"RIGHT": (-1, 0), "LEFT": (1, 0), "DOWN": (0, 1), "UP": (0, -1), "WAIT" : (0, 0)}

    # calculate the action between old_game_state and new_game_state
def cal_action(old_game_state, new_game_state):
    pos_old = np.array(old_game_state["self"][3]) # old agent position
    pos_new = np.array(new_game_state["self"][3]) # new agent position
    act = pos_new-pos_old

    if pos_new[0]-pos_old[0] > 0:
        action = "RIGHT"
    elif pos_new[0]-pos_old[0] < 0:
        action = "LEFT"
    elif pos_new[1]-pos_old[1] < 0:
        action = "UP"
    elif pos_new[1]-pos_old[1] > 0:
        action = "DOWN"
    elif pos_new[0] - pos_old[0] == 0 and pos_new[1] - pos_old[1] == 0:
        action = "WAIT"
    else: action = "ERROR"

    return action


def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: List[str]):
    """
    Called once per step to allow intermediate rewards based on game events.

    When this method is called, self.events will contain a list of all game
    events relevant to your agent that occurred during the previous step. Consult
    settings.py to see what events are tracked. You can hand out rewards to your
    agent based on these events and your knowledge of the (new) game state.

    This is one of the places where you could update your agent.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    :param old_game_state: The state that was passed to the last call of `act`.
    :param self_action: The action that you took.
    :param new_game_state: The state the agent is in now.
    :param events: The events that occurred when going from  `old_game_state` to `new_game_state`
    """

    if old_game_state is None:
        return

    self.logger.debug(f'Encountered game event(s) {", ".join(map(repr, events))} in step {new_game_state["step"]}')

    state = state_to_features(old_game_state)[0]
    agent_pos = np.array(old_game_state["self"][3])
    chosen_action = cal_action(old_game_state, new_game_state)
    new_pos = np.array(agent_pos) + np.array(self.action_dict[chosen_action])

    # define rewards
    if chosen_action == "WAIT":
        pass

    else:
        reward = 1

        a = self.q_dict[chosen_action]
        # calculate new q value
        self.q[state, a] = self.q[state, a] * (1 - ALPHA) + ALPHA * (reward + GAMMA *
                                        np.max(self.q[state_to_features(new_game_state)[0], :]))


def end_of_round(self, last_game_state: dict, last_action: str, events: List[str]):
    """
    Called at the end of each game or when the agent died to hand out final rewards.

    This is similar to reward_update. self.events will contain all events that
    occurred during your agent's final step.

    This is one of the places where you could update your agent.
    This is also a good place to store an agent that you updated.

    :param self: The same object that is passed to all of your callbacks.
    """
    self.logger.debug(f'Encountered event(s) {", ".join(map(repr, events))} in final step')

    # Store the model
    with open("q-avoid_stones.pt", "wb") as file:
        pickle.dump(self.q, file)

    # track the steps of each round
    self.steps.append(last_game_state['step'])
    with open('steps_needed.pt', 'wb') as file:
        pickle.dump(self.steps, file)

    a = np.copy(self.q)
    # self.q_list.append(a)
    # if last_game_state["round"] == 2:
    # with open('q_list.pt', 'wb') as file:
    #    pickle.dump(self.q_list, file)

    # print round
    rounds = 'Runde: {}'.format(last_game_state['round'])
    self.logger.info(rounds)
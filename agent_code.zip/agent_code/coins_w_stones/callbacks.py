import os
import pickle
import random

import numpy as np


EPSILON = 1  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.01
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}


def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    with open("q-avoid_stones.pt", "rb") as file:
        self.q_avoid_stones = pickle.load(file)

    if self.train:
    #if self.train and not os.path.isfile("q-model.pt"):
        pass

    else:
        self.logger.info("Loading model from saved state.")
        with open("q-drop_bomb.pt", "rb") as file:
            self.q_drop_bomb = pickle.load(file)
        with open("q-move_to_coin.pt", "rb") as file:
            self.q_find_coin = pickle.load(file)


def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """
    state = state_to_features(game_state)[0]
    forward = state_to_features(game_state)[1]
    backward = state_to_features(game_state)[2]
    find_coin = state_to_features(game_state)[3]

    rot = state_to_features_stones(game_state)[1]
    action_rot = np.where(self.q_avoid_stones[state_to_features_stones(game_state)[0], :] >= 0)[0]
    best_actions = []
    # action_rot = np.array([action_rot])
    for x in action_rot:
        a = ACTIONS[(x + rot) % 4]
        best_actions.append(a)

    best_actions.append("WAIT")
    best_actions.append("BOMB")

    if find_coin:
        q = self.q_find_coin

    else:
        q = self.q_drop_bomb

    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON
        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)

        # todo Exploration vs exploitation
        EPSILON_THRESHOLD = random.uniform(0,1)
        if EPSILON_THRESHOLD > EPSILON1: #
            action_idx = np.argmax(q[state, :])
            if action_idx == 0:
                action = np.random.choice(forward)
            elif action_idx == 1:
                action = np.random.choice(backward)
            elif action_idx == 2:
                action = "WAIT"
            elif action_idx == 3:
                action = "BOMB"

            if action not in best_actions:
                action = np.random.choice(best_actions[:-1])
            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')

        else:

            action = np.random.choice(best_actions[:-2])
            a = random.uniform(0, 1)
            if a < 0.1:
                action = "WAIT"
            elif a > 0.9:
                action = "BOMB"
            self.logger.debug("Querying model for action.")
            self.logger.info('Moving with Exploration')
            return action
            # return np.random.choice(ACTIONS, p=[.2, .2, .2, .2, 0.1, 0.1])


    else:
        if game_state['step'] == 1:
            return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])
        else:
            action_idx = np.argmax(q[state, :])
            if action_idx == 0:
                action = np.random.choice(forward)
            elif action_idx == 1:
                action = np.random.choice(backward)
            elif action_idx == 2:
                action = "WAIT"
            elif action_idx == 3:
                action = "BOMB"
            if action not in best_actions:
                action = np.random.choice(best_actions[:-1])
            return action



            """
            action_idx = np.argmax(self.q[state_to_features(game_state)[0], 2:])
            action = state_to_features(game_state)[action_idx + 1]
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')

            if len(action) > 1:
                return np.random.choice(action)
            else:
                return action[0]
            """


def state_to_features(game_state: dict) -> np.array:
    """
    This is not a required function, but an idea to structure your code.

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    field = game_state["field"]
    agent_position = np.array(game_state["self"][3])
    coins = np.array(game_state["coins"])
    find_coin = True
    if len(coins) == 0:
        find_coin = False

    if find_coin:
        nearest_coin_idx = np.argmin(np.sum(np.abs(coins-agent_position), axis = 1))
        distance = np.sum(np.abs(coins[nearest_coin_idx] - agent_position))
        nearest_coin = coins[nearest_coin_idx]
    else:
        # find nearest crate
        crate = nearest_crate(field, [game_state["self"][3]], action_dict)
        distance = np.sum(np.abs(crate - agent_position))
        nearest_coin = crate

    forward = []
    backward = []
    if nearest_coin[0] - agent_position[0] > 0:
        forward.append('RIGHT')
        backward.append('LEFT')
    elif nearest_coin[0] - agent_position[0] < 0:
        forward.append('LEFT')
        backward.append('RIGHT')
    elif nearest_coin[0] - agent_position[0] == 0:
        backward.append("LEFT")
        backward.append("RIGHT")

    if nearest_coin[1] - agent_position[1] < 0:
        forward.append('UP')
        backward.append('DOWN')
    elif nearest_coin[1] - agent_position[1] > 0:
        forward.append('DOWN')
        backward.append('UP')
    elif nearest_coin[1] - agent_position[1] == 0:
        backward.append('DOWN')
        backward.append('UP')

    # For example, you could construct several channels of equal shape, ...
    channels = []
    channels.append(distance)
    channels.append(forward)
    channels.append(backward)
    channels.append(find_coin)
    # concatenate them as a feature tensor (they must have the same shape), ...
    #stacked_channels = np.stack(channels)
    # and return them as a vector

    return channels




    #coin_pos = new_game_state['coins']
    #my_pos = new_game_state['self'][3]
    #closest_coin_idx = np.argmin(np.sum(np.abs(coin_pos - my_pos)))
    #closest_coin = coin_pos[closest_coin_idx]

# find coordinates of the fields around the agent in the 4 directions with distance n (numbers_step)
def coordinates_around(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step*np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step*np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step*np.array(action_dict["DOWN"])
    coord_list = np.array([above, right_side, below, left_side])
    return coord_list


# finds the 4 field entries in the 4 directions with distance n (number of steps)
# around a point (agent_position in coordinates)
def surrounding_field(agent_position, number_of_steps, field, action_dict):
    coord_list = coordinates_around(agent_position, number_of_steps, action_dict)
    sur_field = np.ones(4)
    for j in range(4):
        # don't get outside of the field
        if np.max(coord_list[j]) > 16 or np.min(coord_list[j]) < 0:
            sur_field[j] = 505
        else:
            sur_field[j] = field[coord_list[j][0]][coord_list[j][1]]
    return sur_field
# gives back a array with 1, -1, 0 or 505 (outside of the field) [(left, up, right, down)]


def nearest_crate(field, all_pos, action_dict):
    list = []
    if not 1 in field:
        return None
    for pos in all_pos:
        list += np.ndarray.tolist(coordinates_around(pos, 1, action_dict))
    for x in list:
        if np.max(x) > 16 or np.min(x) < 0:
            pass
        else:
            if field[x[0]][x[1]] == 1:
                return np.array(x)
    crate = nearest_crate(field, list, action_dict)
    return crate


def state_to_features_stones(game_state: dict) -> np.array:
    """
    This is not a required function, but an idea to structure your code.

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    # 4 possibilities for the stones and crates surrounding our agent
    field = game_state["field"]
    agent_pos = game_state["self"][3]

    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    above = np.array(agent_pos) + np.array(action_dict["UP"])
    below = np.array(agent_pos) + np.array(action_dict["DOWN"])
    right_side = np.array(agent_pos) + np.array(action_dict["RIGHT"])
    left_side = np.array(agent_pos) + np.array(action_dict["LEFT"])

    surrounding = np.array([field[above[0]] [above[1]],field[right_side[0]][right_side[1]],
                           field[below[0]] [below[1]],field[left_side[0]][left_side[1]]])

    #print(surrounding)

    # find stone_position
    locked_ways = np.count_nonzero(np.abs(surrounding) == 1)
    #print("locked_ways", locked_ways)
    stone_state = locked_ways
    rot = 0

    stone_state, rot = matrix_perm(surrounding)

    #print("surrounding", surrounding, "stone_state", stone_state, "rot", rot)

    channels = []
    channels.append(stone_state)
    channels.append(rot)

    return channels


# find rotation index and state of a matrix (see normed state)
def matrix_perm(matrix):
    locked_ways = np.count_nonzero(np.abs(matrix) == 1)
    # print("locked_ways", locked_ways)
    state = 0
    rot = 0

    # find rotation
    # normed_states = [np.array([0,0,0,0]), np.array([1, 0, 0, 0]), np.array([1, 1, 0, 0]), np.array([0, 1, 1, 1]),
    # np.array([1, 0, 1, 0], np.array([1, 1, 1, 1])
    if locked_ways == 0:
        rot = 0
    elif locked_ways == 1:
        rot = np.where(np.abs(matrix) == 1)[0][0]
        state = 1
    elif locked_ways == 2:
        a, b = np.where(np.abs(matrix) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
            state = 2
        elif a == 1 and b == 2:
            rot = 1
            state = 2
        elif a == 2 and b == 3:
            rot = 2
            state = 2
        elif a == 0 and b == 3:
            rot = 3
            state = 2
        elif a == 0 and b == 2:
            rot = 0
            state = 4
        elif a == 1 and b == 3:
            rot = 1
            state = 4
    elif locked_ways == 3:
        rot = np.where(np.abs(matrix) == 0)[0][0]
        state = 3
    elif state == 4:
        rot = 0
        state = 5

    return state, rot

                



import os
import pickle
import random

import numpy as np


ACTIONS = np.array(['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB'])


EPSILON = 1
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.001

########### ROTATION TABLE #####################################################

rot0 = np.array([0,1,2,3,4])
rot1 = np.array([1,3,0,2,4])
rot2 = np.array([3,2,1,0,4])
rot3 = np.array([2,0,3,1,4])
back_rot = np.vstack((rot0, rot1, rot2, rot3))

corners = np.array([[1,1], [15,15], [1,15], [15,1]])

def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    if self.train:
        # if self.train and not os.path.isfile("movin-model.pt"):
        with open("../avoid_stones/q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)


    else:
        self.logger.info("Loading model from saved state.")
        with open("bomb-model.pt", "rb") as file:
            self.bomb = pickle.load(file)
        with open("../avoid_stones/q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)

def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """
    # todo Exploration vs exploitation


    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON

        agent_pos, bomb_info, state_info = state_to_features(game_state)
        state, rot_index, on_bomb_field, state_matrix = state_info

        EPSILON_THRESHOLD = random.uniform(0, 1)
        if EPSILON_THRESHOLD > EPSILON1:

            action = np.argmax(self.bomb[state, back_rot[rot_index]])

            return ACTIONS[action]

        else: #EXPLORE
            #print(game_state['field'].T)
            stone_state, stone_rot = state_to_features_avoid(game_state)[:2]
            action_rot = np.where(self.avoid_stones[stone_state, :] >= 0)[0]
            self.logger.debug("STONE_STATE: {}".format(stone_state))
            self.logger.debug("aviod: {}".format(self.avoid_stones[stone_state, :]))
            best_actions_idx = []
            for x in action_rot:
                a = (x + stone_rot) % 4
                best_actions_idx.append(a)
            if game_state['self'][2] and (agent_pos[0] and agent_pos[1]) in corners:
                self.logger.debug("best_actions_avoid: {}".format(best_actions_idx))
                return np.random.choice(ACTIONS[best_actions_idx])
            elif game_state['self'][2] and (agent_pos[0] and agent_pos[1]) not in corners:
                best_actions_idx.append(5)
                action = np.random.choice(best_actions_idx)
                self.logger.debug("Chosen action: {}".format(action))
            else:
                # move randomly but without moving into stones or walls to get the exploration more quickly

                self.logger.debug("Best Actions: {}".format(best_actions_idx))
                number = random.uniform(0,1)
                if number > 0.8:
                    action = 4
                else:
                    action = np.random.choice(best_actions_idx)

            self.logger.debug("Chosen action: {}".format(action))
            self.logger.info('Moving with Exploration')
            return ACTIONS[action]
    else:
        self.logger.info('NON training PATH')
        agent_pos, bomb_info, state_info = state_to_features(game_state)
        state, rot_index, on_bomb_field, state_matrix = state_info

        '''
        self.logger.debug("STATE: {}".format(state))
        self.logger.debug("ROT_INDEX: {}".format(rot_index))
        '''
        self.logger.debug("STATE_MATRIX: {}".format(state_matrix))

        self.logger.debug("DEAD_END: {}".format(bomb_info[3]))

        stone_state, stone_rot = state_to_features_avoid(game_state)[:2]
        action_rot = np.where(self.avoid_stones[stone_state, :] >= 0)[0]
        self.logger.debug("STONE_STATE: {}".format(stone_state))
        self.logger.debug("aviod: {}".format(self.avoid_stones[stone_state, :]))
        best_actions_idx = []
        for x in action_rot:
            a = (x + stone_rot) % 4
            best_actions_idx.append(a)
        if game_state['self'][2] and (agent_pos[0] and agent_pos[1]) in corners:

            self.logger.debug("best_actions_avoid: {}".format(best_actions_idx))
            return np.random.choice(ACTIONS[best_actions_idx])

        elif game_state['self'][2] and (agent_pos[0] and agent_pos[1]) not in corners:
            best_actions_idx.append(5)
            action = np.random.choice(best_actions_idx)
            self.logger.debug("Chosen action: {}".format(action))
        else:
            action = np.argmax(self.bomb[state, back_rot[rot_index]])
            self.logger.debug("q_table: {}".format(self.bomb[state, back_rot[rot_index]]))
            self.logger.debug("Chosen action: {}".format(ACTIONS[action]))
        return ACTIONS[action]


#### DEFINITION STATES ############################################################


surround_states = [np.zeros((2, 2))  ,
                    # 5 and 0
                   np.array([[5, 0],
                             [0, 0]]),
                   np.array([[5, 5],
                             [0, 0]]),
                   np.array([[5, 0],
                             [0, 5]]),
                   np.array([[5, 5],
                             [5, 0]]),
                    np.array([[5, 5],
                             [5, 5]]),
                    # 3 and 0
                   np.array([[3, 0],
                             [0, 0]]),
                   np.array([[3, 3],
                             [0, 0]]),
                   np.array([[3, 0],
                             [0, 3]]),
                   np.array([[3, 3],
                             [0, 3]]),
                   np.array([[3, 3],
                             [3, 3]]),

                   # 3 and 5
                    np.array([[3, 5],
                              [5, 5]]),
                    np.array([[3, 3],
                              [5, 5]]),
                    np.array([[4, 3],
                              [5, 5]]),
                    np.array([[3, 5],
                              [5, 3]]),
                    np.array([[3, 4],
                              [5, 5]]),
                   # 3 and 5 and 0
                    np.array([[5, 3],
                              [0, 5]]),
                    np.array([[3, 5],
                              [0, 5]]),
                    np.array([[0, 5],
                              [3, 5]]),
                    np.array([[3, 3],
                              [0, 5]]),
                    np.array([[3, 5],
                              [0, 3]]),
                    np.array([[5, 3],
                              [0, 3]]),
                    np.array([[0, 0],
                              [5, 3]]),
                    np.array([[0, 0],
                              [3, 5]]),
                   np.array([[0, 5],
                             [3, 0]])
                    ]





### ACTION DICTIONARY ####################################################################

action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

##########################################################################################




def state_to_features(game_state: dict) -> np.array:
    """
    *This is not a required function, but an idea to structure your code.*

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    channels = [] #agent_pos, bomb_info, perm_info
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    ### GET THE OPERATIONS IN COORDS #########################################
    field = game_state["field"]
    agent_pos = np.array(game_state['self'][3])

    surround_agent = surrounding_field(agent_pos, 1, field, action_dict)
    coord_around = coordinates_around(agent_pos, 1, action_dict)
    channels.append(agent_pos)

    ### Case: Bomb is dropped #############################################
    if game_state['self'][2] is False:
        bombs = game_state['bombs']
        i = 0
        size = len(bombs)
        bomb_list = []
        bomb_state = []
        while i < size:
            lonely_bomb = bombs[i]
            bomb_time = lonely_bomb[1]
            bomb_coord = lonely_bomb[0]
            bomb_list.append(bomb_coord)
            bomb_state.append(bomb_time)

            i += 1

        bomb_tiles, bomb_field = bomb_fields(bomb_list, field)
        closest_bomb = np.argmin(np.sum(np.abs(agent_pos - np.array(bomb_list)), axis=1))
        bomb_pos = np.array(bomb_list[closest_bomb])
        #print(bomb_list, bomb_field.T)
        surround_agent = surrounding_field(agent_pos, 1, bomb_field, action_dict).reshape(2,2)
        #agent_tiles = agent_fields(agent_pos, bomb_field)


        dead_end = is_dead_end(bomb_tiles, bomb_field, action_dict)
        if (agent_pos[0] and agent_pos[1]) in bomb_pos:
            surround_agent = surround_agent + dead_end
            surround_agent[surround_agent >= 4] = 5



        up_down = bomb_tiles[closest_bomb][0] == [] and  bomb_tiles[closest_bomb][2] == []
        right_left = bomb_tiles[closest_bomb][1] == [] and bomb_tiles[closest_bomb][3] == []
        if up_down and (agent_pos[0] and agent_pos[1]) not in bomb_pos:
            if bomb_pos[0]-agent_pos[0] < 0:
                idx = 1
            else:
                idx = 3
            if 0 not in surround_agent:
                surround_agent.reshape(4)[idx] = 4
                surround_agent.reshape(2,2)
        if right_left and (agent_pos[0] and agent_pos[1]) not in bomb_pos:
            if bomb_pos[1] - agent_pos[1] < 0:
                idx = 0
            else:
                idx = 2
            if 0 not in surround_agent:
                surround_agent.reshape(4)[idx] = 4
                surround_agent.reshape(2, 2)
        surround_agent[np.abs(surround_agent) == 1] = 5
        bomb_info = []

        bomb_info.append(bomb_pos)
        bomb_info.append(bomb_state[closest_bomb])
        bomb_info.append(bomb_fields)
        bomb_info.append(dead_end)

        channels.append(np.array(bomb_info, dtype="object"))

        ### finding matching surroundings to the agent ##################################
        #print(agent_pos)
        on_bomb_field = 0
        if bomb_field[agent_pos[0], agent_pos[1]] == 0:
            on_bomb_field = 1

        match_index, rot_index = find_match(surround_agent)

        state = 4 * match_index + bomb_state[closest_bomb] + 24 * on_bomb_field

        channels.append(np.array([state, rot_index, on_bomb_field, surround_agent], dtype="object"))



    ### Case: no bomb, but check for explosionfields around
    else:
        explosion_map = game_state['explosion_map']

        flames_surround_agent = surrounding_field(agent_pos, 1, explosion_map, action_dict)

        surround_agent = (surround_agent + flames_surround_agent).reshape(2,2)
        surround_agent[surround_agent != 0] = 5
        match_index, rot_index = find_match(surround_agent)

        state = 2 * 4 * 24 + match_index
        on_bomb_field = 1
        channels.append([None]*4)
        channels.append(np.array([state, rot_index, on_bomb_field, surround_agent], dtype="object"))


    return channels


def coordinates_around(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step*np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step*np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step*np.array(action_dict["DOWN"])
    coord_list = np.array([above, right_side, below, left_side])
    return coord_list


def bomb_fields(bomb_list, gamefield):
    field = np.copy(gamefield)
    all_bomb_tiles = []
    for bomb in bomb_list:
        i = 1
        j = 1
        k = 1
        l = 1

        up = []
        right = []
        down = []
        left = []
        #field[bomb] = 8
        while field[bomb[0]+i, bomb[1]] == 0 and i < 4:
            field[bomb[0] + i, bomb[1]] = 3
            right.append((bomb[0] + i, bomb[1]))
            i += 1

        while field[bomb[0]-j, bomb[1]] == 0 and j < 4:
            field[bomb[0] - j, bomb[1]] = 3
            left.append((bomb[0] - j, bomb[1]))
            j += 1

        while field[bomb[0], bomb[1]-k] == 0 and k < 4:
            field[bomb[0], bomb[1] - k] = 3
            up.append((bomb[0], bomb[1] - k))
            k += 1


        while field[bomb[0], bomb[1] + l] == 0 and l < 4:
            field[bomb[0], bomb[1] + l] = 3
            down.append((bomb[0], bomb[1] + l))
            l += 1
        #field[bomb] = 3
        all_bomb_tiles.append(np.array([up, right, down, left, bomb], dtype="object"))
    return all_bomb_tiles, field

def surrounding_field(agent_position, number_of_steps, field, action_dict):
    coord_list = coordinates_around(agent_position, number_of_steps, action_dict)
    sur_field = np.ones(4)
    for j in range(4):
        # don't get outside of the field
        if np.max(coord_list[j]) > 16 or np.min(coord_list[j]) < 0:
            sur_field[j] = 505
        else:
            sur_field[j] = field[coord_list[j][0]][coord_list[j][1]]
    return sur_field


def is_dead_end(bomb_list, bomb_field, action_dict):
    bomb_up = bomb_list[0][0]
    bomb_right = bomb_list[0][1]
    bomb_down = bomb_list[0][2]
    bomb_left = bomb_list[0][3]
    agent_pos = bomb_list[0][4]
    zero = 5 * np.ones(4)
    up = np.array([])
    if len(bomb_up) != 0:

        for x in bomb_up:
            up = np.hstack((up, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in up:
        zero[0] = 0

    right = np.array([])
    if len(bomb_right) != 0:

        for x in bomb_right:
            right = np.hstack((right, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in right:
        zero[1] = 0

    down = np.array([])
    if len(bomb_down) != 0:

        for x in bomb_down:
            down = np.hstack((down, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in down:
        zero[2] = 0

    left = np.array([])
    if len(bomb_left) != 0:

        for x in bomb_left:
            left = np.hstack((left, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in left:
        zero[3] = 0

    surround_agent = surrounding_field(agent_pos, 1, bomb_field, action_dict)
    #print(surround_agent)
    direction = np.where(surround_agent == 0)
    zero[direction] = 0
    return zero.reshape(2,2)


def find_match(A):
    match_index = 0
    size = len(surround_states)
    #print(A)
    i = 0
    r = 0
    a = True
    while a == True and i < size:
        #print(i)
        if np.all(A == surround_states[i]) == True:
            match_index = i
            r = 0
            a = False
        i += 1

    j = 0
    while a == True and j < size:
        #print(j)
        B = np.rot90(A, k=1)
        if np.all(B == surround_states[j]) == True:
            match_index = j
            r = 1
            a = False
        j += 1

    k = 0
    while a == True and k < size:
        #print(k)
        C = np.rot90(A, k=2)
        if np.all(C == surround_states[k]) == True:
            match_index = k
            r = 2
            a = False
        k += 1

    l = 0
    while a == True and l < size:
        #print(l)
        D = np.rot90(A, k=3)
        if np.all(D == surround_states[l]) == True:
            match_index = l
            r = 3
            a = False
        l += 1
    return match_index, r


def state_to_features_avoid(game_state: dict) -> np.array:
    """
    This is not a required function, but an idea to structure your code.

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    # 4 possibilities for the stones and crates surrounding our agent
    field = game_state["field"]
    agent_pos = game_state["self"][3]

    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    above = np.array(agent_pos) + np.array(action_dict["UP"])
    below = np.array(agent_pos) + np.array(action_dict["DOWN"])
    right_side = np.array(agent_pos) + np.array(action_dict["RIGHT"])
    left_side = np.array(agent_pos) + np.array(action_dict["LEFT"])

    surrounding = np.array([field[left_side[0]][left_side[1]], field[above[0]] [above[1]],
                        field[right_side[0]][right_side[1]], field[below[0]] [below[1]]])

    # find stone_position
    locked_ways = np.count_nonzero(np.abs(surrounding) == 1)
    #print("locked_ways", locked_ways)
    stone_state = locked_ways
    rot = 0
    #print(surrounding)
    #print("stone_state", stone_state)
    # find rotation
    #normed_states = [np.array([[0,0],[0, 0]]), np.array([[1, 0], [0, 0]]), np.array([[1, 1], [0, 0]]), np.array([[0, 1], [1, 1]]), np.array([[1, 0], [0, 1]]])
    if stone_state == 0:
        rot = 0
    elif stone_state == 1:
        rot = np.where(np.abs(surrounding) == 1)[0][0]
    elif stone_state == 2:
        a, b = np.where(np.abs(surrounding) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
        elif a == 1 and b == 2:
            rot = 1
        elif a == 2 and b == 3:
            rot = 2
        elif a == 0 and b == 3:
            rot = 3
        elif a == 0 and b == 2:
            rot = 0
            stone_state = 4
        elif a == 1 and b == 3:
            rot = 1
            stone_state = 4

    elif stone_state == 3:
        rot = np.where(np.abs(surrounding) == 0)[0][0]

    #print("surrounding", surrounding, "stone_state", stone_state, "rot", rot)

    channels = []
    channels.append(stone_state)
    channels.append(rot)

    return channels

'''
def agent_fields(agent_pos, field):
    i = 1
    j = 1
    k = 1
    l = 1

    up = []
    right = []
    down = []
    left = []

    while field[agent_pos[0] + i, agent_pos[1]] == 3:
        # field[agent_pos[0] + i, agent_pos[1]] = 3
        right.append((agent_pos[0] + i, agent_pos[1]))
        i += 1

    while field[agent_pos[0] - j, agent_pos[1]] == 3:
        # field[agent_pos[0] - j, agent_pos[1]] = 3
        left.append((agent_pos[0] - j, agent_pos[1]))
        j += 1

    while field[agent_pos[0], agent_pos[1] - k] == 3:
        # field[agent_pos[0], agent_pos[1] - k] = 3
        up.append((agent_pos[0], agent_pos[1] - k))
        k += 1

    while field[agent_pos[0], agent_pos[1] + l] == 3:
        # field[agent_pos[0], agent_pos[1] + l] = 3
        down.append((agent_pos[0], agent_pos[1] + l))
        l += 1

    agent_fields = [np.array([up, right, down, left, agent_pos], dtype="object")]

    return agent_fields'''
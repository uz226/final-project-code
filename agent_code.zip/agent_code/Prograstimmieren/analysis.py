import numpy as np
import pickle

data = pickle.load('steps_needed.pt')

import os
import pickle
import random

import numpy as np


EPSILON = 1  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.001
ACTIONS = ['LEFT', 'UP', 'RIGHT', 'DOWN', 'WAIT', 'BOMB'] # !!!!
#ACTIONS = ['RIGHT', 'DOWN', 'LEFT', 'UP', 'WAIT', 'BOMB'] # !!!!


def setup(self):
    """
    Setup your code. This is called once when loading each agent.
    Make sure that you prepare everything such that act(...) can be called.

    When in training mode, the separate `setup_training` in train.py is called
    after this method. This separation allows you to share your trained agent
    with other students, without revealing your training code.

    In this example, our model is a set of probabilities over actions
    that are is independent of the game state.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """

    # if self.train:
    if self.train and not os.path.isfile("q-drop_bomb.pt"):
        with open("q-avoid_stones.pt", "rb") as file:
            self.q_avoid_stones = pickle.load(file)

    else:
        self.logger.info("Loading model from saved state.")
        with open("q-drop_bomb.pt", "rb") as file:
            self.q_drop_bomb = pickle.load(file)
        with open("q-avoid_stones.pt", "rb") as file:
            self.q_avoid_stones = pickle.load(file)

    self.q_dict = {"LEFT": 0, "UP": 1, "RIGHT": 2, "DOWN": 3, "WAIT": 4, "BOMB": 5}
    self.action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}
    #self.action_dict = {"RIGHT": (0, 1), "LEFT": (0, -1), "DOWN": (0, 1), "UP": (0, -1)}


def act(self, game_state: dict) -> str:
    """
    Your agent should parse the input, think, and take a decision.
    When not in training mode, the maximum execution time for this method is 0.5s.

    :param self: The same object that is passed to all of your callbacks.
    :param game_state: The dictionary that describes everything on the board.
    :return: The action to take as a string.
    """

    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON

        # print EPSILON
        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)

        # todo Exploration vs exploitation
        EPSILON_THRESHOLD = random.uniform(0, 1)
        if EPSILON_THRESHOLD > EPSILON1:
            # choose action with highest value in q-table
            stone_state, stone_rot = state_to_features(game_state)[:2]
            crate_state, crate_rot = state_to_features(game_state)[2:4]
            # if highest value is bombing, action is bombing
            if np.argmax(self.q_drop_bomb[crate_state, :]) == 5:
                action = "BOMB"
            else:
                # choose best direction depending stones and crates
                values_1 = self.q_avoid_stones[stone_state, :]
                values_2 = self.q_drop_bomb[crate_state, :4]
                # action_rot = np.array([action_rot])
                values_stone = np.ones(4)
                values_crate = np.ones(4)
                for i in range(4):
                    a = (i + stone_rot) % 4
                    values_stone[a] = values_1[i]
                    b = (i + crate_rot) % 4
                    values_crate[b] = values_2[i]
                values = values_stone + values_crate
                action = ACTIONS[np.argmax(values)]

            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action

        else:
            # move randomly but without moving into stones or walls to get the exploration more quickly
            stone_state, stone_rot = state_to_features(game_state)[:2]
            action_rot = np.where(self.q_avoid_stones[stone_state, :] >= 0)[0]
            best_actions_idx = []
            for x in action_rot:
                a = ACTIONS[(x + stone_rot) % 4]
                best_actions_idx.append(a)
            action1 = np.random.choice(best_actions_idx)
            action = [action1, "BOMB"]
            self.logger.debug("Querying model for action.")
            self.logger.info('Moving with Exploration')
            return np.random.choice(action, p = [0.6, 0.4])
            # 75% probability to move (without going into stones or crates), 25 % probability to bomb

    else:
        if game_state['step'] is None:
            return np.random.choice(ACTIONS, p = [0.25, 0.25, 0.25, 0.25, 0, 0])
        else:
            # choose action with highest value in q-table
            stone_state, stone_rot = state_to_features(game_state)[:2]
            crate_state, crate_rot = state_to_features(game_state)[2:4]
            # choose best direction depending stones and crates
            values_1 = self.q_avoid_stones[stone_state, :]
            values_2 = self.q_drop_bomb[crate_state, :4]
            # action_rot = np.array([action_rot])
            values_stone = np.ones(4)
            values_crate = np.ones(4)
            for i in range(4):
                a = (i + stone_rot) % 4
                values_stone[a] = values_1[i]
                b = (i + crate_rot) % 4
                values_crate[b] = values_2[i]
            print("position", game_state["self"][3])
            print("sur_field", surrounding_field(game_state["self"][3], 1, game_state["field"], self.action_dict))
            print("stone", values_stone, "rot", state_to_features(game_state)[1])
            print("crate_state", state_to_features(game_state)[5], "rot", state_to_features(game_state)[3],
                  "state", state_to_features(game_state)[2])  # , "corner", state_to_features(game_state)[6])
            print("values_crates", values_crate, self.q_drop_bomb[crate_state, 4])
            print("n-crates", state_to_features(game_state)[4])

            values = 20 * values_stone + values_crate
            values = np.append(values, self.q_drop_bomb[crate_state, 4]-10)
            values = np.append(values, self.q_drop_bomb[crate_state, 5])
            print("values", values)
            print(np.argmax(values))
            action = ACTIONS[np.argmax(values)]

        self.logger.info('Moving with Exploitation')
        self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
        return action


def state_to_features(game_state: dict) -> np.array:
    """
    *This is not a required function, but an idea to structure your code.*

    Converts the game state to the input of your model, i.e.
    a feature vector.

    You can find out about the state of the game environment via game_state,
    which is a dictionary. Consult 'get_state_for_agent' in environment.py to see
    what it contains.

    :param game_state:  A dictionary describing the current game board.
    :return: np.array
    """
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    field = game_state["field"]
    agent_pos = game_state["self"][3]
    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    """create stone_state"""
    # surrounding field entries
    sur_field = surrounding_field(agent_pos, 1, field, action_dict)
    # state and rotation
    stone_state, stone_rot = matrix_perm(sur_field)

    """create crate_state"""
    sur_coord = coordinates_around(np.array(agent_pos), 1, action_dict)
    n_now = crate_list(agent_pos, field, action_dict)
    n_left = crate_list(sur_coord[0], field, action_dict)
    n_up = crate_list(np.array(sur_coord[1]), field, action_dict)
    n_right = crate_list(np.array(sur_coord[2]), field, action_dict)
    n_down = crate_list(np.array(sur_coord[3]), field, action_dict)

    crates_around = np.zeros(4)
    if n_left > n_now: crates_around[0] = 1
    if n_up > n_now: crates_around[1] = 1
    if n_right > n_now: crates_around[2] = 1
    if n_down > n_now: crates_around[3] = 1

    # crate_state, in corners they should not bomb
    crate_state, crate_rot = matrix_perm(crates_around)
    if crate_state == 0:
        if n_now == 0:
            crate_state = 6

    # For example, you could construct several channels of equal shape, ...
    channels = []
    channels.append(stone_state)
    channels.append(stone_rot)
    channels.append(crate_state)
    channels.append(crate_rot)
    channels.append(n_now)
    channels.append(crates_around)
    return channels


# find coordinates of the fields around the agent in the 4 directions with distance n (numbers_step)
def coordinates_around(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step*np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step*np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step*np.array(action_dict["DOWN"])
    coord_list = np.array([left_side, above, right_side, below])
    return coord_list

# gives back the number of crates (des_crates) you would destroy with a bomb in center_position
# you also can use bomb_list which is an array that contains all the field entries for
# around the center in each direction within 3 steps
def crate_list(center_position, field, action_dict):
    if (center_position[0] == 1 or center_position[0] == 15) and (center_position[1] == 1 or center_position[1] == 15):
        des_crates = 0

    else:
        """Matrix with the field entries from all places a bomb would reach"""
        left = []
        up = []
        right = []
        down = []
        for i in range(3):
            sur_field = surrounding_field(center_position, i+1, field, action_dict)
            a, b, c, d = sur_field
            if a != 505:
                left.append(a)
            if b != 505:
                up.append(b)
            if c != 505:
                right.append(c)
            if d != 505:
                down.append(d)

        bomb_list = [left, up, right, down]
        #print("center", center_position)
        #print("bomblist", bomb_list)
        # find number of crates a bomb would destroy
        des_crates = 0
        for x in bomb_list:
            # stop on a wall
            i = 0
            while i < len(x) and x[i] != -1:
                if x[i] == 1:
                    des_crates += 1
         #           print("x", x, "i", i)
                i += 1
    #print(des_crates)
    return des_crates


# finds the 4 field entries in the 4 directions with distance n (number of steps)
# around a point (agent_position in coordinates)
def surrounding_field(agent_position, number_of_steps, field, action_dict):
    coord_list = coordinates_around(agent_position, number_of_steps, action_dict)
    sur_field = np.ones(4)
    for j in range(4):
        # don't get outside of the field
        if np.max(coord_list[j]) > 16 or np.min(coord_list[j]) < 0:
            sur_field[j] = 505
        else:
            sur_field[j] = field[coord_list[j][0]][coord_list[j][1]]
    return sur_field
# gives back a array with 1, -1, 0 or 505 (outside of the field) [(left, up, right, down)]


# find rotation index and state of a matrix (see normed state)
def matrix_perm(matrix):
    locked_ways = np.count_nonzero(np.abs(matrix) == 1)
    # print("locked_ways", locked_ways)
    state = 0
    rot = 0

    # find rotation
    # normed_states = [np.array([0,0,0,0]), np.array([1, 0, 0, 0]), np.array([1, 1, 0, 0]), np.array([0, 1, 1, 1]),
    # np.array([1, 0, 1, 0], np.array([1, 1, 1, 1])
    if locked_ways == 0:
        rot = 0
    elif locked_ways == 1:
        rot = np.where(np.abs(matrix) == 1)[0][0]
        state = 1
    elif locked_ways == 2:
        a, b = np.where(np.abs(matrix) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
            state = 2
        elif a == 1 and b == 2:
            rot = 1
            state = 2
        elif a == 2 and b == 3:
            rot = 2
            state = 2
        elif a == 0 and b == 3:
            rot = 3
            state = 2
        elif a == 0 and b == 2:
            rot = 0
            state = 4
        elif a == 1 and b == 3:
            rot = 1
            state = 4
    elif locked_ways == 3:
        rot = np.where(np.abs(matrix) == 0)[0][0]
        state = 3
    elif state == 4:
        rot = 0
        state = 5

    return state, rot


def find_corner(agent_position):
    corner = 0
    if agent_position == (1, 1):
        corner = 1
    elif agent_position == (15, 1):
        corner = 2
    elif agent_position == (15, 15):
        corner = 3
    elif agent_position == (1, 15):
        corner = 4
    elif agent_position == (1, 2) or agent_position == (2, 1):
        corner = 5
    elif agent_position == (14, 1) or agent_position == (15, 2):
        corner = 6
    elif agent_position == (14, 15) or agent_position == (15, 14):
        corner = 7
    elif agent_position == (1, 14) or agent_position == (2, 15):
        corner = 8
    return corner
import os
import pickle
import random

import numpy as np

ACTIONS = np.array(['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB'])

EPSILON = 1
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.0001

########### ROTATION TABLE #####################################################

rot0 = np.array([0, 1, 2, 3, 4])
rot1 = np.array([3, 0, 1, 2, 4])
rot2 = np.array([2, 3, 0, 1, 4])
rot3 = np.array([1, 2, 3, 0, 4])
back_rot = np.vstack((rot0, rot1, rot2, rot3))

corners = np.array([[1, 1], [15, 15], [1, 15], [15, 1]])


def setup(self):
    if self.train:
        # if self.train and not os.path.isfile("movin-model.pt"):
        with open("q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)


    else:
        self.logger.info("Loading model from saved state.")
        with open("bomb-model.pt", "rb") as file:
            self.bomb = pickle.load(file)
        with open("q-avoid_stones.pt", "rb") as file:
            self.avoid_stones = pickle.load(file)


def act(self, game_state: dict) -> str:
    # todo Exploration vs exploitation

    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(
                -EPSILON_DECAY_RATE * (game_state['round'] - 1))
        else:
            EPSILON1 = EPSILON

        agent_pos, bomb_info, state_info = state_to_features(game_state)
        state, rot_index, on_bomb_field, surround, state_surround = state_info

        EPSILON_THRESHOLD = random.uniform(0, 1)
        if EPSILON_THRESHOLD > EPSILON1:
            # print("EXLOITATION")

            action = np.argmax(self.bomb[state, back_rot[rot_index]])

            return ACTIONS[action]

        else:  # EXPLORE
            # print("EXPLORATION")
            stone_state, stone_rot = state_to_features_avoid(game_state)[:2]
            action_rot = np.where(self.avoid_stones[stone_state, :] >= 0)[0]
            self.logger.debug("STONE_STATE: {}".format(stone_state))
            self.logger.debug("aviod: {}".format(self.avoid_stones[stone_state, :]))
            best_actions_idx = []
            for x in action_rot:
                a = (x + stone_rot) % 4
                best_actions_idx.append(a)
                # choose random between the actions possible without running into crates or stones or bomb
            best_actions_idx.append(4)
            if game_state['self'][2] and (agent_pos[0] and agent_pos[1]) in corners:
                self.logger.debug("best_actions_avoid: {}".format(best_actions_idx))
                # choose random between the actions possible without running into crates or stones
                # do not bomb because you are in a corner or it is not allowed
                return np.random.choice(ACTIONS[best_actions_idx])

            elif game_state['self'][2] and (agent_pos[0] and agent_pos[1]) not in corners:
                best_actions_idx.append(4)
                best_actions_idx.append(5)
                action = np.random.choice(best_actions_idx)
                # do not bomb because it is not allowed, choose between the rest without running into stones
                self.logger.debug("Chosen action: {}".format(action))
            else:
                # move randomly but without moving into stones or walls to get the exploration more quickly

                self.logger.debug("Best Actions: {}".format(best_actions_idx))
                number = random.uniform(0, 1)
                if number > 0.8:
                    action = 4
                else:
                    action = np.random.choice(best_actions_idx)

            self.logger.debug("Chosen action: {}".format(action))
            self.logger.info('Moving with Exploration')
            return ACTIONS[action]
    else:
        self.logger.info('NON training PATH')
        agent_pos, bomb_info, state_info = state_to_features(game_state)
        state, rot_index, on_bomb_field, surrounding, state_matrix= state_info

        '''
        self.logger.debug("STATE: {}".format(state))
        self.logger.debug("ROT_INDEX: {}".format(rot_index))
        '''
        self.logger.debug("STATE_MATRIX: {}".format(state_matrix))

        self.logger.debug("dead_end: {}".format(bomb_info[3]))

        # look at the best actions without moving into a stone
        stone_state, stone_rot = state_to_features_avoid(game_state)[:2]
        action_rot = np.where(self.avoid_stones[stone_state, :] >= 0)[0]
        self.logger.debug("STONE_STATE: {}".format(stone_state))
        self.logger.debug("aviod: {}".format(self.avoid_stones[stone_state, :]))
        best_actions_idx = []
        for x in action_rot:
            a = (x + stone_rot) % 4
            best_actions_idx.append(a)
        best_actions_idx.append(4)

        # you are in a corner, you don´t have to escape, don´t bomb, choose randomly
        if game_state['self'][2] and (agent_pos[0] and agent_pos[1]) in corners:

            self.logger.debug("best_actions_avoid: {}".format(best_actions_idx))
            action = np.random.choice(ACTIONS[best_actions_idx])
            return action

        # you are allowed to bomb, you don´t have to escape, choose randomly and maybe bomb
        elif game_state['self'][2] and (agent_pos[0] and agent_pos[1]) not in corners:
            best_actions_idx.append(5)
            action = np.random.choice(best_actions_idx)
            self.logger.debug("Chosen action: {}".format(action))

        # choose best action by model
        else:
            action = np.argmax(self.bomb[state, back_rot[rot_index]])
            self.logger.debug("q_table: {}".format(self.bomb[state, back_rot[rot_index]]))
            self.logger.debug("Chosen action: {}".format(ACTIONS[action]))

        return ACTIONS[action]


#### DEFINITION STATES ############################################################


surround_states = [np.zeros((2, 2)),
                   # 5 and 0
                   np.array([[5, 0],
                             [0, 0]]),
                   np.array([[5, 5],
                             [0, 0]]),
                   np.array([[5, 0],
                             [0, 5]]),
                   np.array([[5, 5],
                             [5, 0]]),
                   np.array([[5, 5],
                             [5, 5]]),

                   # 0 and 3
                   np.array([[3, 0],
                             [0, 0]]),
                   np.array([[3, 3],
                             [0, 0]]),
                   np.array([[3, 0],
                             [0, 3]]),
                   np.array([[3, 3],
                             [3, 0]]),
                   np.array([[3, 3],
                             [3, 3]]),

                   # 3 and 5
                   np.array([[3, 5],
                             [5, 5]]),
                   np.array([[3, 3],
                             [5, 5]]),
                   np.array([[3, 5],
                             [5, 3]]),
                   np.array([[3, 3],
                             [3, 5]]),

                   # 3 and 5 and 0
                   np.array([[5, 3],
                             [0, 5]]),
                   np.array([[3, 5],
                             [0, 5]]),
                   np.array([[0, 5],
                             [3, 5]]),
                   np.array([[3, 3],
                             [0, 5]]),
                   np.array([[3, 5],
                             [0, 3]]),
                   np.array([[5, 3],
                             [0, 3]]),
                   np.array([[0, 0],
                             [5, 3]]),
                   np.array([[0, 0],
                             [3, 5]]),
                   np.array([[0, 5],
                             [3, 0]])
                   ]

### ACTION DICTIONARY ####################################################################

action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}


##########################################################################################


def state_to_features(game_state: dict) -> np.array:
    channels = []  # agent_pos, bomb_info, perm_info
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    ### GET THE OPERATIONS IN COORDS #########################################
    field = game_state["field"]
    agent_pos = np.array(game_state['self'][3])

    surround_agent = surrounding_field(agent_pos, 1, field, action_dict)

    channels.append(agent_pos)

    ### Case: Bomb is dropped #############################################
    if len(game_state["bombs"]) != 0:
        bombs = game_state['bombs']
        i = 0
        size = len(bombs)
        bomb_list = []
        bomb_state = []
        while i < size:
            lonely_bomb = bombs[i]
            bomb_time = lonely_bomb[1]
            bomb_coord = lonely_bomb[0]
            bomb_list.append(bomb_coord)
            bomb_state.append(bomb_time)

            i += 1

        # find closest_bomb and create bomb_field
        bomb_tiles, bomb_field = bomb_fields(bomb_list, field)
        closest_bomb = np.argmin(np.sum(np.abs(agent_pos - np.array(bomb_list)), axis=1))
        bomb_pos = np.array(bomb_list[closest_bomb])

        # find surrounding of the agent
        surround_agent = surrounding_field(agent_pos, 1, bomb_field, action_dict)
        # find dead ends
        dead_end = dead_end_func(agent_pos, bomb_pos, bomb_field, action_dict)

        # combine surrounding and dead ends
        surrounding = surround_agent + dead_end
        surrounding[surrounding >= 4] = 5
        surrounding[np.abs(surrounding) == 1] = 5
        surround_agent = surrounding

        on_bomb_field = 0
        if bomb_field[agent_pos[0], agent_pos[1]] == 0:
            on_bomb_field = 1

        bomb_info = []

        bomb_info.append(bomb_pos)
        bomb_info.append(bomb_state[closest_bomb])
        bomb_info.append(bomb_fields)
        bomb_info.append(dead_end)

        channels.append(np.array(bomb_info, dtype="object"))

        ### finding matching surroundings to the agent ##################################
        surround_agent = np.array([[surround_agent[0], surround_agent[1]], [surround_agent[3], surround_agent[2]]])
        match_index, rot_index = find_match(surround_agent)

        state = 24 * on_bomb_field + match_index

        channels.append(
            np.array([state, rot_index, on_bomb_field, surround_agent, surround_states[match_index]], dtype="object"))


    ### Case: no bomb, but check for explosionfields around
    else:
        explosion_map = game_state['explosion_map']

        flames_surround_agent = surrounding_field(agent_pos, 1, explosion_map, action_dict)
        surround_agent = surrounding_field(agent_pos, 1, field, action_dict)
        surround_agent = surround_agent + flames_surround_agent

        on_bomb_field = 1
        if explosion_map[agent_pos[0], agent_pos[1]] != 0:
            on_bomb_field = 0

        surround_agent[surround_agent != 0] = 5
        surround_agent = np.array([[surround_agent[0], surround_agent[1]], [surround_agent[3], surround_agent[2]]])
        match_index, rot_index = find_match(surround_agent)

        state = 24*on_bomb_field + match_index
        on_bomb_field = 1
        channels.append([None] * 4)
        channels.append(
            np.array([state, rot_index, on_bomb_field, surround_agent, surround_states[match_index]], dtype="object"))

    return channels


# gives back the coordinates around an position in the up, right, down and left direction with distance numbers_step
def coordinates_around(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step * np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step * np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step * np.array(action_dict["DOWN"])
    coord_list = np.array([above, right_side, below, left_side])
    return coord_list


# fill in the field array with the bomb tiles (tiles where an explosion will happen)
def bomb_fields(bomb_list, gamefield):
    field = np.copy(gamefield)
    all_bomb_tiles = []
    for bomb in bomb_list:
        i = 1
        j = 1
        k = 1
        l = 1

        up = []
        right = []
        down = []
        left = []
        field[bomb] = 3
        while field[bomb[0] + i, bomb[1]] == 0 and i < 4:
            field[bomb[0] + i, bomb[1]] = 3
            right.append((bomb[0] + i, bomb[1]))
            i += 1

        while field[bomb[0] - j, bomb[1]] == 0 and j < 4:
            field[bomb[0] - j, bomb[1]] = 3
            left.append((bomb[0] - j, bomb[1]))
            j += 1

        while field[bomb[0], bomb[1] - k] == 0 and k < 4:
            field[bomb[0], bomb[1] - k] = 3
            up.append((bomb[0], bomb[1] - k))
            k += 1

        while field[bomb[0], bomb[1] + l] == 0 and l < 4:
            field[bomb[0], bomb[1] + l] = 3
            down.append((bomb[0], bomb[1] + l))
            l += 1

        all_bomb_tiles.append(np.array([up, right, down, left, bomb], dtype="object"))
    return all_bomb_tiles, field


def surrounding_field(agent_position, number_of_steps, field, action_dict):
    coord_list = coordinates_around(agent_position, number_of_steps, action_dict)
    sur_field = np.ones(4)
    for j in range(4):
        # don't get outside of the field
        if np.max(coord_list[j]) > 16 or np.min(coord_list[j]) < 0:
            sur_field[j] = 505
        else:
            sur_field[j] = field[coord_list[j][0]][coord_list[j][1]]
    return sur_field


"""
# first dead end function, replaced by the dead_end_func at the end of file
def is_dead_end(bomb_list, bomb_field, action_dict):
    bomb_up = bomb_list[0][0]
    bomb_right = bomb_list[0][1]
    bomb_down = bomb_list[0][2]
    bomb_left = bomb_list[0][3]
    agent_pos = bomb_list[0][4]
    zero = 5 * np.ones(4)
    up = np.array([])
    if len(bomb_up) != 0:

        for x in bomb_up:
            up = np.hstack((up, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in up:
        zero[0] = 0

    right = np.array([])
    if len(bomb_right) != 0:

        for x in bomb_right:
            right = np.hstack((right, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in right:
        zero[1] = 0

    down = np.array([])
    if len(bomb_down) != 0:

        for x in bomb_down:
            down = np.hstack((down, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in down:
        zero[2] = 0

    left = np.array([])
    if len(bomb_left) != 0:

        for x in bomb_left:
            left = np.hstack((left, surrounding_field(x, 1, bomb_field, action_dict)))

    if 0 in left:
        zero[3] = 0

    surround_agent = surrounding_field(agent_pos, 1, bomb_field, action_dict)
    #print(surround_agent)
    direction = np.where(surround_agent == 0)
    zero[direction] = 0
    return zero.reshape(2,2)
"""

# finds the rotation index and the matching index of a matrix and the surround_states (defined at beginning of file)
def find_match(A):
    match_index = 0
    size = len(surround_states)
    # print(A)
    i = 0
    r = 0
    a = True
    while a == True and i < size:
        # print(i)
        if np.all(A == surround_states[i]) == True:
            match_index = i
            r = 0
            a = False
        i += 1

    j = 0
    while a == True and j < size:
        # print(j)
        B = np.rot90(A, k=1)
        if np.all(B == surround_states[j]) == True:
            match_index = j
            r = 1
            a = False
        j += 1

    k = 0
    while a == True and k < size:
        # print(k)
        C = np.rot90(A, k=2)
        if np.all(C == surround_states[k]) == True:
            match_index = k
            r = 2
            a = False
        k += 1

    l = 0
    while a == True and l < size:
        # print(l)
        D = np.rot90(A, k=3)
        if np.all(D == surround_states[l]) == True:
            match_index = l
            r = 3
            a = False
        l += 1
    return match_index, r


def state_to_features_avoid(game_state: dict) -> np.array:
    if game_state is None:
        return None

    # 4 possibilities for the stones and crates surrounding our agent
    field = game_state["field"]
    agent_pos = game_state["self"][3]

    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    """create stone_state"""
    # surrounding field entries
    sur_field = surrounding_field(agent_pos, 1, field, action_dict)
    # state and rotation
    stone_state, stone_rot = matrix_perm(sur_field)

    channels = []
    channels.append(stone_state)
    channels.append(stone_rot)

    return channels


# find rotation index and state of a matrix (see normed state)
def matrix_perm(matrix):
    locked_ways = np.count_nonzero(np.abs(matrix) == 1)
    state = 0
    rot = 0

    # find rotation
    # normed_states = [np.array([0,0,0,0]), np.array([1, 0, 0, 0]), np.array([1, 1, 0, 0]), np.array([0, 1, 1, 1]),
    # np.array([1, 0, 1, 0], np.array([1, 1, 1, 1])
    if locked_ways == 0:
        rot = 0
    elif locked_ways == 1:
        rot = np.where(np.abs(matrix) == 1)[0][0]
        state = 1
    elif locked_ways == 2:
        a, b = np.where(np.abs(matrix) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
            state = 2
        elif a == 1 and b == 2:
            rot = 1
            state = 2
        elif a == 2 and b == 3:
            rot = 2
            state = 2
        elif a == 0 and b == 3:
            rot = 3
            state = 2
        elif a == 0 and b == 2:
            rot = 0
            state = 4
        elif a == 1 and b == 3:
            rot = 1
            state = 4
    elif locked_ways == 3:
        rot = np.where(np.abs(matrix) == 0)[0][0]
        state = 3
    elif state == 4:
        rot = 0
        state = 5

    return state, rot


"""
def agent_fields(agent_pos, bomb_pos, bomb_field):
    i = 1
    j = 1
    k = 1
    l = 1
    field = np.copy(bomb_field)
    field[bomb_pos] = -8
    #print(field.T)
    up = []
    right = []
    down = []
    left = []

    while field[agent_pos[0] + i, agent_pos[1]] == 3:
        # field[agent_pos[0] + i, agent_pos[1]] = 3
        right.append((agent_pos[0] + i, agent_pos[1]))
        i += 1

    while field[agent_pos[0] - j, agent_pos[1]] == 3:
        # field[agent_pos[0] - j, agent_pos[1]] = 3
        left.append((agent_pos[0] - j, agent_pos[1]))
        j += 1

    while field[agent_pos[0], agent_pos[1] - k] == 3:
        # field[agent_pos[0], agent_pos[1] - k] = 3
        up.append((agent_pos[0], agent_pos[1] - k))
        k += 1

    while field[agent_pos[0], agent_pos[1] + l] == 3:
        # field[agent_pos[0], agent_pos[1] + l] = 3
        down.append((agent_pos[0], agent_pos[1] + l))
        l += 1

    agent_fields = [np.array([up, right, down, left, agent_pos], dtype="object")]

    return agent_fields
"""


# dead end function, gives back an array surrounding that has an entry 5 if in this direction there
# is a dead end full of bomb fields and 0 otherwise
def dead_end_func(agent_pos, bomb_pos, bomb_field, action_dict):
    a = action_dict
    field = np.copy(bomb_field)
    field[bomb_pos[0], bomb_pos[1]] = -8
    i = 1
    j = 1
    k = 1
    l = 1
    surrounding = np.array([5, 5, 5, 5])

    sur = surrounding_field(agent_pos, 1, field, a)
    if sur[0] == 0:
        surrounding[0] = 0
    if sur[1] == 0:
        surrounding[1] = 0
    if sur[2] == 0:
        surrounding[2] = 0
    if sur[3] == 0:
        surrounding[3] = 0

    while field[agent_pos[0] + i, agent_pos[1]] == 3:
        if 0 in surrounding_field((agent_pos[0] + i, agent_pos[1]), 1, field, a):
            surrounding[1] = 0
        i += 1

    while field[agent_pos[0] - j, agent_pos[1]] == 3:
        if 0 in surrounding_field((agent_pos[0] - j, agent_pos[1]), 1, field, a):
            surrounding[3] = 0
        j += 1

    while field[agent_pos[0], agent_pos[1] - k] == 3:
        if 0 in surrounding_field((agent_pos[0], agent_pos[1] - k), 1, field, a):
            surrounding[0] = 0
        k += 1

    while field[agent_pos[0], agent_pos[1] + l] == 3:
        if 0 in surrounding_field((agent_pos[0], agent_pos[1] + l), 1, field, a):
            surrounding[2] = 0
        l += 1

    return surrounding

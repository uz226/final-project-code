import os
import pickle
import random

import numpy as np


EPSILON = 1  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.001
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}


def setup(self):
    with open("q-avoid_stones.pt", "rb") as file:
        self.q_avoid_stones = pickle.load(file)

    if self.train:
        pass

    else:
        self.logger.info("Loading model from saved state.")
        with open("q-drop_bomb.pt", "rb") as file:
            self.q_drop_bomb = pickle.load(file)
        with open("q-move_to_coin.pt", "rb") as file:
            self.q_move_to_coin = pickle.load(file)


def act(self, game_state: dict) -> str:
    state_stone, rot = state_to_features_stones(game_state)
    state_coin, forward_coin, backward_coin = state_to_features_coins(game_state)
    state_crate, forward_crate, backward_crate = state_to_features_crates(game_state)

    # change everything to state_coin, forward_coin, backward_coin if you want to use that

    action_rot = np.where(self.q_avoid_stones[state_stone, :] >= 0)[0]
    best_actions = []
    # action_rot = np.array([action_rot])
    for x in action_rot:
        a = ACTIONS[(x + rot) % 4]
        best_actions.append(a)
    best_actions.append("WAIT")
    best_actions.append("BOMB")

    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON
        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)

        # todo Exploration vs exploitation
        EPSILON_THRESHOLD = random.uniform(0,1)
        if EPSILON_THRESHOLD > EPSILON1: #
            action_idx = np.argmax(self.q_drop_bomb[state_crate, :])
            if action_idx == 0 and forward_crate != []:
                action = np.random.choice(forward_crate)
            elif action_idx == 1 and backward_crate != []:
                action = np.random.choice(backward_crate)
            elif action_idx == 2:
                action = "WAIT"
            elif action_idx == 3:
                action = "BOMB"
            else:
                action = np.random.choice(ACTIONS[:-2])
            if action not in best_actions:
                action = np.random.choice(best_actions[:])
            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')

        else:
            """
            action = np.random.choice(best_actions[:-2])
            a = random.uniform(0, 1)
            if a < 0.1:
                action = "WAIT"
            elif a > 0.998:
                action = "BOMB"
            """
            self.logger.debug("Querying model for action.")
            self.logger.info('Moving with Exploration')
            return np.random.choice(ACTIONS, p=[.2, .2, .2, .2, 0.1, 0.1])

    else:
        if game_state['step'] == 1:
            return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])
        else:
            action_idx = np.argmax(self.q_drop_bomb[state_crate, :]) #!!
            if action_idx == 0:
                action = np.random.choice(forward_crate)
            elif action_idx == 1:
                action = np.random.choice(backward_crate)
            elif action_idx == 2:
                action = "WAIT"
            elif action_idx == 3:
                action = "BOMB"
            if action not in best_actions:
                action = np.random.choice(best_actions[:-1])
            return action


def state_to_features_coins(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    agent_position = np.array(game_state["self"][3])
    coins = np.array(game_state["coins"])

    if len(coins) == 0:
        state = 2 # state 2: standing somewhere on the field without coins
        forward = ["UP", "RIGHT"]
        backward = ["DOWN", "LEFT"]

    else:
        nearest_coin_idx = np.argmin(np.sum(np.abs(coins-agent_position), axis = 1))
        distance = np.sum(np.abs(coins[nearest_coin_idx] - agent_position))
        nearest_coin = coins[nearest_coin_idx]
        if distance == 1: #  state 0: standing on the coin
            state = 0
        elif distance > 1 or distance == 0: # state 1: standing somewhere on the field
            state = 1

        forward, backward = forward_backward(agent_position, nearest_coin)

    channels = []
    channels.append(state)
    channels.append(forward)
    channels.append(backward)

    return channels


def state_to_features_crates(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    field = game_state["field"]
    agent_position = np.array(game_state["self"][3])

    if 1 not in field:
        state = 2  # state 2: standing somewhere on the field without crates
        forward = ["UP", "RIGHT"]
        backward = ["DOWN", "LEFT"]

    else:
        crate = nearest_crate(field, [agent_position], action_dict)
        distance = np.sum(np.abs(crate - agent_position))
        if distance == 1:  # state 0: standing one in front of the crate
            state = 0
        elif distance > 1:  # state 1: standing somewhere on the field
            state = 1
        forward, backward = forward_backward(agent_position, crate)

    channels = []
    channels.append(state)
    channels.append(forward)
    channels.append(backward)
    return channels


def state_to_features_stones(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    field = game_state["field"]
    agent_pos = game_state["self"][3]
    surrounding = surrounding_field(agent_pos, 1, field, action_dict)
    stone_state, rot = matrix_perm(surrounding)

    channels = []
    channels.append(stone_state)
    channels.append(rot)
    return channels

# matches the actions up, right, down, left to forward and backward state actions based on the thing_position
def forward_backward(agent_position, thing_position):
    forward = []
    backward = []
    if thing_position[0] - agent_position[0] > 0:
        forward.append('RIGHT')
        backward.append('LEFT')
    elif thing_position[0] - agent_position[0] < 0:
        forward.append('LEFT')
        backward.append('RIGHT')
    elif thing_position[0] - agent_position[0] == 0:
        backward.append("LEFT")
        backward.append("RIGHT")

    if thing_position[1] - agent_position[1] < 0:
        forward.append('UP')
        backward.append('DOWN')
    elif thing_position[1] - agent_position[1] > 0:
        forward.append('DOWN')
        backward.append('UP')
    elif thing_position[1] - agent_position[1] == 0:
        backward.append('DOWN')
        backward.append('UP')

    return forward, backward


# find coordinates of the fields around the agent in the 4 directions with distance n (numbers_step)
def coordinates_around(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step*np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step*np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step*np.array(action_dict["DOWN"])
    coord_list = np.array([above, right_side, below, left_side])
    return coord_list


# finds the 4 field entries in the 4 directions with distance n (number of steps)
# around a point (agent_position in coordinates)
def surrounding_field(agent_position, number_of_steps, field, action_dict):
    coord_list = coordinates_around(agent_position, number_of_steps, action_dict)
    sur_field = np.ones(4)
    for j in range(4):
        # don't get outside of the field
        if np.max(coord_list[j]) > 16 or np.min(coord_list[j]) < 0:
            sur_field[j] = 505
        else:
            sur_field[j] = field[coord_list[j][0]][coord_list[j][1]]
    return sur_field
# gives back a array with 1, -1, 0 or 505 (outside of the field) [(left, up, right, down)]


# finds the nearest crate given a agent position, output are the coordinates of the nearest crate
def nearest_crate(field, all_pos, action_dict):
    list = []
    if not 1 in field:
        return None
    for pos in all_pos:
        list += np.ndarray.tolist(coordinates_around(pos, 1, action_dict))
    for x in list:
        if np.max(x) > 16 or np.min(x) < 0:
            pass
        else:
            if field[x[0]][x[1]] == 1:
                return np.array(x)
    crate = nearest_crate(field, list, action_dict)
    return crate


# find rotation index and state of a matrix (see normed state)
def matrix_perm(matrix):
    locked_ways = np.count_nonzero(np.abs(matrix) == 1)
    # print("locked_ways", locked_ways)
    state = 0
    rot = 0

    # find rotation
    # normed_states = [np.array([0,0,0,0]), np.array([1, 0, 0, 0]), np.array([1, 1, 0, 0]), np.array([0, 1, 1, 1]),
    # np.array([1, 0, 1, 0], np.array([1, 1, 1, 1])
    if locked_ways == 0:
        rot = 0
    elif locked_ways == 1:
        rot = np.where(np.abs(matrix) == 1)[0][0]
        state = 1
    elif locked_ways == 2:
        a, b = np.where(np.abs(matrix) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
            state = 2
        elif a == 1 and b == 2:
            rot = 1
            state = 2
        elif a == 2 and b == 3:
            rot = 2
            state = 2
        elif a == 0 and b == 3:
            rot = 3
            state = 2
        elif a == 0 and b == 2:
            rot = 0
            state = 4
        elif a == 1 and b == 3:
            rot = 1
            state = 4
    elif locked_ways == 3:
        rot = np.where(np.abs(matrix) == 0)[0][0]
        state = 3
    elif state == 4:
        rot = 0
        state = 5

    return state, rot

                



import pickle
import os
import random
from collections import namedtuple, deque
from typing import List

import events as e
from .callbacks import state_to_features_crates
from .callbacks import state_to_features_coins
import numpy as np

GAMMA = 0.9  # discount factor
ALPHA = 0.6  # learning rate


def setup_training(self):

    #self.steps = []
    self.q_list = []
    self.rewards = []
    self.reward = 0
    #if not os.path.isfile("q-drop_bomb_first_approach (not used).pt"):
    if True:
        self.logger.info("Setting up hyperparam")
        #self.q_move_to_coin = np.zeros((3, 4)) # forward backward wait bomb
        self.q_drop_bomb = np.zeros((3, 4))

    with open("q-move_to_coin.pt", "rb") as file:
        self.q_move_to_coin = pickle.load(file)
    """
    else:
        self.logger.info("Loading model from saved state.")
        with open("q-drop_bomb_first_approach (not used).pt", "rb") as file:
            self.q_drop_bomb = pickle.load(file)
        with open("q-move_to_coin.pt", "rb") as file:
            self.q_move_to_coin = pickle.load(file)"""


def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: List[str]):

    if old_game_state is None:
        return

    self.logger.debug(f'Encountered game event(s) {", ".join(map(repr, events))} in step {new_game_state["step"]}')

    state_coin, forward_coin, backward_coin = state_to_features_coins(old_game_state)
    state_crate, forward_crate, backward_crate = state_to_features_crates(old_game_state)
    state_coin_new = state_to_features_coins(new_game_state)[0]
    state_crate_new = state_to_features_crates(new_game_state)[0]

    # print(forward, backward)
    if self_action == "WAIT":
        a = 2
        b = 2
    elif self_action == "BOMB":
        a = 3
        b = 3
    if self_action in forward_coin:
        a = 0
    elif self_action in backward_coin:
        a = 1
    if self_action in forward_crate:
        b = 0
    elif self_action in backward_crate:
        b = 1

    if self_action is None:
        return

    reward_coin = -1
    reward_crate = -1
    if state_coin == 0 and a == 0:  # you find the coin
        reward_coin = 10
    if state_crate == 0 and b == 3:
        reward_crate = 10 # you bomb the crate
    self.q_move_to_coin[state_coin, a] = self.q_move_to_coin[state_coin, a] * (1 - ALPHA) + ALPHA * (reward_coin +
                                 GAMMA * np.max(self.q_move_to_coin[state_coin_new, :]))
        #print(self.q_find_coin[state, a])

    self.q_drop_bomb[state_crate, b] = self.q_drop_bomb[state_crate, b] * (1 - ALPHA) + ALPHA * (reward_crate +
                            GAMMA * np.max(self.q_drop_bomb[state_crate_new, :]))

    self.reward += reward_crate
    # state_to_features is defined in callbacks.py
    #self.Transitions.append(Transition(state_to_features(old_game_state)[0], self_action, state_to_features(new_game_state)[0], reward_from_events(self, events)))


def end_of_round(self, last_game_state: dict, last_action: str, events: List[str]):
    """
    Called at the end of each game or when the agent died to hand out final rewards.

    This is similar to reward_update. self.events will contain all events that
    occurred during your agent's final step.

    This is one of the places where you could update your agent.
    This is also a good place to store an agent that you updated.

    :param self: The same object that is passed to all of your callbacks.
    """
    self.logger.debug(f'Encountered event(s) {", ".join(map(repr, events))} in final step')
    #self.transitions.append(Transition(state_to_features(last_game_state), last_action, None, reward_from_events(self, events)))

    # Store the model
    with open("q-move_to_coin.pt", "wb") as file:
        pickle.dump(self.q_move_to_coin, file)
    with open("q-drop_bomb.pt", "wb") as file:
        pickle.dump(self.q_drop_bomb, file)
    # track the steps of each round
    self.rewards.append(self.reward/last_game_state['step'])
    with open('reward_crate.pt', 'wb') as file:
        pickle.dump(self.rewards, file)
    self.reward = 0
    #a = np.copy(self.q)
    #self.q_list.append(a)
    #if last_game_state["round"] == 2:
    #with open('q_list.pt', 'wb') as file:
    #    pickle.dump(self.q_list, file)
    rounds = 'Runde: {}'.format(last_game_state['round'])
    self.logger.info(rounds)

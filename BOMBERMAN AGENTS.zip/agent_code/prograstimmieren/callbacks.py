import os
import pickle
import random
from .functions import coordinates_around, nearest_crate_2, \
    surrounding_field, matrix_perm, forward_backward, \
    dead_end_func, find_match, bomb_fields, bomb_positions

import numpy as np

EPSILON = 1  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.01
ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

########### ROTATION TABLE #####################################################

rot0 = np.array([0, 1, 2, 3, 4])
rot1 = np.array([3, 0, 1, 2, 4])
rot2 = np.array([2, 3, 0, 1, 4])
rot3 = np.array([1, 2, 3, 0, 4])
back_rot = np.vstack((rot0, rot1, rot2, rot3))

corners = np.array([[1, 1], [15, 15], [1, 15], [15, 1]])

#################################################################################

surround_states = [np.zeros((2, 2)),
                   # 5 and 0
                   np.array([[5, 0],
                             [0, 0]]),
                   np.array([[5, 5],
                             [0, 0]]),
                   np.array([[5, 0],
                             [0, 5]]),
                   np.array([[5, 5],
                             [5, 0]]),
                   np.array([[5, 5],
                             [5, 5]]),

                   # 0 and 3
                   np.array([[3, 0],
                             [0, 0]]),
                   np.array([[3, 3],
                             [0, 0]]),
                   np.array([[3, 0],
                             [0, 3]]),
                   np.array([[3, 3],
                             [3, 0]]),
                   np.array([[3, 3],
                             [3, 3]]),

                   # 3 and 5
                   np.array([[3, 5],
                             [5, 5]]),
                   np.array([[3, 3],
                             [5, 5]]),
                   np.array([[3, 5],
                             [5, 3]]),
                   np.array([[3, 3],
                             [3, 5]]),

                   # 3 and 5 and 0
                   np.array([[5, 3],
                             [0, 5]]),
                   np.array([[3, 5],
                             [0, 5]]),
                   np.array([[0, 5],
                             [3, 5]]),
                   np.array([[3, 3],
                             [0, 5]]),
                   np.array([[3, 5],
                             [0, 3]]),
                   np.array([[5, 3],
                             [0, 3]]),
                   np.array([[0, 0],
                             [5, 3]]),
                   np.array([[0, 0],
                             [3, 5]]),
                   np.array([[0, 5],
                             [3, 0]])
                   ]

##########################################################################################


def setup(self):
    with open("q-avoid_stones.pt", "rb") as file:
        self.q_avoid_stones = pickle.load(file)
    with open("q-drop_bomb.pt", "rb") as file:
        self.q_drop_bomb = pickle.load(file)
    with open("q-move_to_coin.pt", "rb") as file:
        self.q_move_to_coin = pickle.load(file)
    with open("q-avoid_bomb.pt", "rb") as file:
        self.q_avoid_bomb = pickle.load(file)
    self.logger.info("Loading model from saved state.")


def act(self, game_state: dict) -> str:
    if game_state['step'] == 1:
        return np.random.choice(ACTIONS, p=[.25, .25, .25, .25, 0, 0])

    state_stone, rot_stone = state_to_features_stones(game_state)
    values_stone = np.zeros(6)
    for i in range(0, 4):
        # values of the q-avoid_stones table
        j = (i + rot_stone) % 4
        action_val = self.q_avoid_stones[state_stone, i]
        values_stone[j] = action_val
        # now we have values_stones

    state_coin, forward_coin, backward_coin = state_to_features_coins(game_state)
    values_coins = np.zeros(6)
    for i in range(0, 4):
        # values of q-moving_to_coin
        if ACTIONS[i] in forward_coin:
            a = self.q_move_to_coin[state_coin, 0]
        elif ACTIONS[i] in backward_coin:
            a = self.q_move_to_coin[state_coin, 1]
        else:
            a = None
        values_coins[i] = a
    values_coins[4:] = self.q_move_to_coin[state_coin, 2:]
    # now we have values go to coin

    state_crate, forward_crate, backward_crate = state_to_features_crates(game_state)
    values_crate = np.zeros(6)
    for i in range(0, 4):
        # values of q-moving_to_coin
        if ACTIONS[i] in forward_crate:
            a = self.q_drop_bomb[state_crate, 0]
        elif ACTIONS[i] in backward_crate:
            a = self.q_drop_bomb[state_crate, 1]
        else:
            a = None
        values_crate[i] = a
    values_crate[4:] = self.q_drop_bomb[state_crate, 2:]
    # now we have values for dropping bombs


    values_avoid_bomb = np.zeros(6)
    bomb_pos = bomb_positions(game_state)
    for i in range(len(bomb_pos)):
        state_bomb, rot_bomb = state_to_features_avoid_bombs(game_state, bomb_pos[i])[:2]
        bomb = self.q_avoid_bomb[state_bomb, back_rot[rot_bomb]]
        bomb = np.append(bomb, np.min(bomb))
        values_avoid_bomb += (5-i)*bomb
    # now we have the values of avoiding bombs

    # putting everything together with the right weight
    values = 1000*values_stone + 10*values_coins + 100*values_avoid_bomb + values_crate
    """
    print("avoid_stones", values_stone)
    print("avoid_bombs", values_avoid_bomb)
    print("coins", values_coins)
    print("crates", values_crate)
    print("values", values)
    """

    # choose between the highest values
    if game_state["self"][2]:
        action = np.where(values == np.max(values))[0]
    # do not choose bombing if you have no bomb
    else:
        action = np.where(values == np.max(values[:-1]))[0]

    action = ACTIONS[np.random.choice(action)]
    #if game_state["step"]%6 == 1:
    #    action = "BOMB"
    return action


def state_to_features_coins(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    agent_position = np.array(game_state["self"][3])
    coins = np.array(game_state["coins"])

    if len(coins) == 0:
        state = 2 # state 3: standing somewhere on the field without coins
        forward = ["UP", "RIGHT", "DOWN", "LEFT"]
        backward = []

    else:
        nearest_coin_idx = np.argmin(np.sum(np.abs(coins-agent_position), axis = 1))
        distance = np.sum(np.abs(coins[nearest_coin_idx] - agent_position))
        nearest_coin = coins[nearest_coin_idx]
        if distance == 1: #  state 0: standing on the coin
            state = 0
        elif distance > 1: # state 1: standing somewhere on the field
            state = 1

        forward, backward = forward_backward(agent_position, nearest_coin)

    channels = []
    channels.append(state)
    channels.append(forward)
    channels.append(backward)

    return channels


def state_to_features_crates(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None
    field = game_state["field"]
    agent_position = np.array(game_state["self"][3])

    if 1 not in field:
        state = 2  # state 3: standing somewhere on the field without crates
        forward = ["UP", "RIGHT"]
        backward = ["DOWN", "LEFT"]

    else:
        #crate = nearest_crate(field, [agent_position], [[agent_position]], action_dict)
        crate = nearest_crate_2(field, agent_position)
        distance = np.sum(np.abs(crate - agent_position))
        if distance == 1:  # state 0: standing one in front of the crate
            state = 0
        elif distance > 1:  # state 1: standing somewhere on the field
            state = 1
        forward, backward = forward_backward(agent_position, crate)

    channels = []
    channels.append(state)
    channels.append(forward)
    channels.append(backward)
    return channels


def state_to_features_stones(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    field = game_state["field"]
    agent_pos = game_state["self"][3]
    surrounding = surrounding_field(agent_pos, 1, field, action_dict)
    stone_state, rot = matrix_perm(surrounding)

    channels = []
    channels.append(stone_state)
    channels.append(rot)
    return channels


def state_to_features_avoid_bombs(game_state: dict, bomb_position) -> np.array:
    channels = []  # agent_pos, bomb_info, perm_info
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    ### GET THE OPERATIONS IN COORDS #########################################
    field = game_state["field"]
    agent_pos = np.array(game_state['self'][3])

    ### Case: Bomb is dropped #############################################
    if len(game_state["bombs"]) != 0:
        bombs = game_state['bombs']
        i = 0
        size = len(bombs)
        bomb_list = []
        while i < size:
            lonely_bomb = bombs[i]
            bomb_coord = lonely_bomb[0]
            bomb_list.append(bomb_coord)
            i += 1

        bomb_tiles, bomb_field = bomb_fields(bomb_list, field)
        bomb_pos = bomb_position
        ###################################################


        # find surrounding
        surround_agent = surrounding_field(agent_pos, 1, bomb_field, action_dict)
        dead_end = dead_end_func(agent_pos, bomb_pos, bomb_field, action_dict)
        surrounding = surround_agent + dead_end
        surrounding[surrounding >= 4] = 5
        surrounding[np.abs(surrounding) == 1] = 5
        surround_agent = surrounding

        # agent on bomb_field or not
        on_bomb_field = 0
        if bomb_field[agent_pos[0], agent_pos[1]] == 0:
            on_bomb_field = 1

        ### finding matching surroundings to the agent ##################################
        surround_agent = np.array([[surround_agent[0], surround_agent[1]], [surround_agent[3], surround_agent[2]]])
        match_index, rot_index = find_match(surround_agent)
        state = 24 * on_bomb_field + match_index
        channels.append(state)
        channels.append(rot_index)


    ### Case: no bomb, but check for explosionfields around
    explosion_map = game_state['explosion_map']

    flames_surround_agent = surrounding_field(agent_pos, 1, explosion_map, action_dict)
    surround_agent = surrounding_field(agent_pos, 1, field, action_dict)
    surround_agent = surround_agent + flames_surround_agent

    on_bomb_field = 1
    if explosion_map[agent_pos[0], agent_pos[1]] != 0:
        on_bomb_field = 0
    surround_agent[surround_agent != 0] = 5


    ### Case: Bomb is dropped #############################################
    if len(game_state["bombs"]) != 0:
        bombs = game_state['bombs']
        i = 0
        size = len(bombs)
        bomb_list = []
        while i < size:
            lonely_bomb = bombs[i]
            bomb_coord = lonely_bomb[0]
            bomb_list.append(bomb_coord)
            i += 1

        bomb_tiles, bomb_field = bomb_fields(bomb_list, field)
        bomb_pos = bomb_position
        ###################################################


        # find surrounding
        surround_agent_2 = surrounding_field(agent_pos, 1, bomb_field, action_dict)
        dead_end = dead_end_func(agent_pos, bomb_pos, bomb_field, action_dict)
        surrounding = surround_agent_2 + dead_end
        surrounding[surrounding >= 4] = 5
        surrounding[np.abs(surrounding) == 1] = 5
        surround_agent = surrounding + surround_agent
        surround_agent[surround_agent >= 4] = 5
        surround_agent[np.abs(surround_agent) == 1] = 5

        # agent on bomb_field or not
        if bomb_field[agent_pos[0], agent_pos[1]] != 0:
            on_bomb_field = 0

    ### finding matching surroundings to the agent ##################################
    """
    if np.len(np.where(surround_agent==5))<3:
        # find nearest opponent
        opponent_list = game_state['others']
        i = 0
        size = len(opponent_list)
        opponent_coord = []

        while i < size:
            lonely_opp = opponent_list[i]
            opp_coord = lonely_opp[3]
            opponent_coord.append(opp_coord)
            i += 1

        opponent_coordinates = np.array(opponent_coord)
        nearest_opp_idx = np.argmin(np.sum(np.abs(np.array(opponent_coordinates) - agent_pos), axis=1))
        distance = np.min(np.sum(np.abs(np.array(opponent_coordinates) - agent_pos), axis=1))
        opp = opponent_coordinates[nearest_opp_idx]
        if distance <= 6
    """



    surround_agent = np.array([[surround_agent[0], surround_agent[1]], [surround_agent[3], surround_agent[2]]])
    match_index, rot_index = find_match(surround_agent)
    state = 24 * on_bomb_field + match_index
    channels.append(state)
    channels.append(rot_index)

    return channels


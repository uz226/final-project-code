import numpy as np

#### DEFINITION STATES ############################################################


surround_states = [np.zeros((2, 2)),
                   # 5 and 0
                   np.array([[5, 0],
                             [0, 0]]),
                   np.array([[5, 5],
                             [0, 0]]),
                   np.array([[5, 0],
                             [0, 5]]),
                   np.array([[5, 5],
                             [5, 0]]),
                   np.array([[5, 5],
                             [5, 5]]),

                   # 0 and 3
                   np.array([[3, 0],
                             [0, 0]]),
                   np.array([[3, 3],
                             [0, 0]]),
                   np.array([[3, 0],
                             [0, 3]]),
                   np.array([[3, 3],
                             [3, 0]]),
                   np.array([[3, 3],
                             [3, 3]]),

                   # 3 and 5
                   np.array([[3, 5],
                             [5, 5]]),
                   np.array([[3, 3],
                             [5, 5]]),
                   np.array([[3, 5],
                             [5, 3]]),
                   np.array([[3, 3],
                             [3, 5]]),

                   # 3 and 5 and 0
                   np.array([[5, 3],
                             [0, 5]]),
                   np.array([[3, 5],
                             [0, 5]]),
                   np.array([[0, 5],
                             [3, 5]]),
                   np.array([[3, 3],
                             [0, 5]]),
                   np.array([[3, 5],
                             [0, 3]]),
                   np.array([[5, 3],
                             [0, 3]]),
                   np.array([[0, 0],
                             [5, 3]]),
                   np.array([[0, 0],
                             [3, 5]]),
                   np.array([[0, 5],
                             [3, 0]])
                   ]


def bomb_positions(game_state):
    bombs = game_state['bombs']
    i = 0
    size = len(bombs)
    bomb_list = []
    while i < size:
        lonely_bomb = bombs[i]
        bomb_coord = lonely_bomb[0]
        bomb_list.append(bomb_coord)
        i += 1
    return bomb_list


def dead_end_func(agent_pos, bomb_pos, bomb_field, action_dict):
    # print("you are in the dead_end_func")
    a = action_dict
    field = np.copy(bomb_field)
    # print("bomb_pos", bomb_pos)
    field[bomb_pos[0], bomb_pos[1]] = -8
    # print(field.T)
    i = 1
    j = 1
    k = 1
    l = 1
    surrounding = np.array([5, 5, 5, 5])
    # print(agent_pos)
    # print("surrounding_field", surrounding_field((agent_pos[0] + i, agent_pos[1]), 1, field, a))

    sur = surrounding_field(agent_pos, 1, field, a)
    if sur[0] == 0:
        surrounding[0] = 0
    if sur[1] == 0:
        surrounding[1] = 0
    if sur[2] == 0:
        surrounding[2] = 0
    if sur[3] == 0:
        surrounding[3] = 0

    while field[agent_pos[0] + i, agent_pos[1]] == 3:

        #   print("surrounding_field_right", surrounding_field((agent_pos[0] + i, agent_pos[1]), 1, field, a))
        if 0 in surrounding_field((agent_pos[0] + i, agent_pos[1]), 1, field, a):
            # print("surrounding_field_right", surrounding_field((agent_pos[0] + i, agent_pos[1]), 1, field, a))
            surrounding[1] = 0
        #        print("here", surrounding)
        i += 1
    # print(surrounding)

    while field[agent_pos[0] - j, agent_pos[1]] == 3:
        # print("left", surrounding_field((agent_pos[0] -j , agent_pos[1]), 1, field,  a))
        if 0 in surrounding_field((agent_pos[0] - j, agent_pos[1]), 1, field, a):
            surrounding[3] = 0
        #    print("here", surrounding)
        j += 1

    while field[agent_pos[0], agent_pos[1] - k] == 3:
        # print("up", surrounding_field((agent_pos[0] , agent_pos[1]-k), 1, field, a))
        if 0 in surrounding_field((agent_pos[0], agent_pos[1] - k), 1, field, a):
            surrounding[0] = 0
        #   print("here", surrounding)
        k += 1

    while field[agent_pos[0], agent_pos[1] + l] == 3:
        # print("down", surrounding_field((agent_pos[0] , agent_pos[1] + l), 1, field,  a))
        if 0 in surrounding_field((agent_pos[0], agent_pos[1] + l), 1, field, a):
            surrounding[2] = 0
            # print("here", surrounding)
        l += 1

    return surrounding


def find_match(A):
    match_index = 0
    size = len(surround_states)
    # print(A)
    i = 0
    r = 0
    a = True
    while a == True and i < size:
        # print(i)
        if np.all(A == surround_states[i]) == True:
            match_index = i
            r = 0
            a = False
        i += 1

    j = 0
    while a == True and j < size:
        # print(j)
        B = np.rot90(A, k=1)
        if np.all(B == surround_states[j]) == True:
            match_index = j
            r = 1
            a = False
        j += 1

    k = 0
    while a == True and k < size:
        # print(k)
        C = np.rot90(A, k=2)
        if np.all(C == surround_states[k]) == True:
            match_index = k
            r = 2
            a = False
        k += 1

    l = 0
    while a == True and l < size:
        # print(l)
        D = np.rot90(A, k=3)
        if np.all(D == surround_states[l]) == True:
            match_index = l
            r = 3
            a = False
        l += 1
    return match_index, r


def bomb_fields(bomb_list, gamefield):
    field = np.copy(gamefield)
    all_bomb_tiles = []
    for bomb in bomb_list:
        i = 1
        j = 1
        k = 1
        l = 1

        up = []
        right = []
        down = []
        left = []
        field[bomb] = 3
        while field[bomb[0] + i, bomb[1]] == 0 and i < 4:
            field[bomb[0] + i, bomb[1]] = 3
            right.append((bomb[0] + i, bomb[1]))
            i += 1

        while field[bomb[0] - j, bomb[1]] == 0 and j < 4:
            field[bomb[0] - j, bomb[1]] = 3
            left.append((bomb[0] - j, bomb[1]))
            j += 1

        while field[bomb[0], bomb[1] - k] == 0 and k < 4:
            field[bomb[0], bomb[1] - k] = 3
            up.append((bomb[0], bomb[1] - k))
            k += 1

        while field[bomb[0], bomb[1] + l] == 0 and l < 4:
            field[bomb[0], bomb[1] + l] = 3
            down.append((bomb[0], bomb[1] + l))
            l += 1

        all_bomb_tiles.append(np.array([up, right, down, left, bomb], dtype="object"))
    return all_bomb_tiles, field


def forward_backward(agent_position, thing_position):
    forward = []
    backward = []
    if thing_position[0] - agent_position[0] > 0:
        forward.append('RIGHT')
        backward.append('LEFT')
    elif thing_position[0] - agent_position[0] < 0:
        forward.append('LEFT')
        backward.append('RIGHT')
    elif thing_position[0] - agent_position[0] == 0:
        backward.append("LEFT")
        backward.append("RIGHT")

    if thing_position[1] - agent_position[1] < 0:
        forward.append('UP')
        backward.append('DOWN')
    elif thing_position[1] - agent_position[1] > 0:
        forward.append('DOWN')
        backward.append('UP')
    elif thing_position[1] - agent_position[1] == 0:
        backward.append('DOWN')
        backward.append('UP')

    return forward, backward


# find coordinates of the fields around the agent in the 4 directions with distance n (numbers_step)
def coordinates_around(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step*np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step*np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step*np.array(action_dict["DOWN"])
    coord_list = np.array([above, right_side, below, left_side])
    return coord_list


# find coordinates of the fields around the agent in the 4 directions with distance n (numbers_step)
def coordinates_around_2(agent_position, numbers_step, action_dict):
    left_side = np.array(agent_position) + numbers_step*np.array(action_dict["LEFT"])
    above = np.array(agent_position) + numbers_step * np.array(action_dict["UP"])
    right_side = np.array(agent_position) + numbers_step*np.array(action_dict["RIGHT"])
    below = np.array(agent_position) + numbers_step*np.array(action_dict["DOWN"])
    coord_list = [(above[0], above[1]), (right_side[0], right_side[1]), (below[0], below[1]), (left_side[0], left_side[1])]
    return coord_list


# finds the 4 field entries in the 4 directions with distance n (number of steps)
# around a point (agent_position in coordinates)
def surrounding_field(agent_position, number_of_steps, field, action_dict):
    coord_list = coordinates_around(agent_position, number_of_steps, action_dict)
    sur_field = np.ones(4)
    for j in range(4):
        # don't get outside of the field
        if np.max(coord_list[j]) > 16 or np.min(coord_list[j]) < 0:
            sur_field[j] = 505
        else:
            sur_field[j] = field[coord_list[j][0]][coord_list[j][1]]
    return sur_field
# gives back a array with 1, -1, 0 or 505 (outside of the field) [(left, up, right, down)]


# finds the nearest crate given a agent position, output are the coordinates of the nearest crate
def nearest_crate(field, all_pos, already_seen, action_dict):
    list = []
    if not 1 in field:
        return None
    for pos in all_pos:
        list += coordinates_around_2(pos, 1, action_dict)
        list = sorted(set(list), key=list.index)
        print(list)
    for x in list:
        print(x)
        print(already_seen)
        if np.max(x) > 16 or np.min(x) < 0 or x in already_seen:
            pass
        else:
            if field[x[0]][x[1]] == 1:
                return np.array(x)

    crate = nearest_crate(field, list, list, action_dict)
    return crate

#####################################################################################
def nearest_crate_2(field, agent_position):
    coord_crates = np.where(field == 1)
    coord_crates = np.vstack((coord_crates[0], coord_crates[1])).T
    coord_distance = np.sum(np.abs(coord_crates - agent_position), axis=1)
    crate = coord_crates[np.argmin(coord_distance)]
    return crate



# find rotation index and state of a matrix (see normed state)
def matrix_perm(matrix):
    locked_ways = np.count_nonzero(np.abs(matrix) == 1)
    # print("locked_ways", locked_ways)
    state = 0
    rot = 0

    # find rotation
    # normed_states = [np.array([0,0,0,0]), np.array([1, 0, 0, 0]), np.array([1, 1, 0, 0]), np.array([0, 1, 1, 1]),
    # np.array([1, 0, 1, 0], np.array([1, 1, 1, 1])
    if locked_ways == 0:
        rot = 0
    elif locked_ways == 1:
        rot = np.where(np.abs(matrix) == 1)[0][0]
        state = 1
    elif locked_ways == 2:
        a, b = np.where(np.abs(matrix) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
            state = 2
        elif a == 1 and b == 2:
            rot = 1
            state = 2
        elif a == 2 and b == 3:
            rot = 2
            state = 2
        elif a == 0 and b == 3:
            rot = 3
            state = 2
        elif a == 0 and b == 2:
            rot = 0
            state = 4
        elif a == 1 and b == 3:
            rot = 1
            state = 4
    elif locked_ways == 3:
        rot = np.where(np.abs(matrix) == 0)[0][0]
        state = 3
    elif state == 4:
        rot = 0
        state = 5

    return state, rot

def setup_training(self):
    # initialize variables only needed for training
    pass

def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    # called after each step, collect training data and fill experience buffer
    # learning should take place
    pass

def end_of_round(self, last_game_state, last_action, events):
    # similar to previous but after the last step of a round
    # learning should take place
    pass

# events = list of game events that happened as a consequence of the agents actions (page 6)



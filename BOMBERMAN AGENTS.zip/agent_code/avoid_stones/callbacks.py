import os
import pickle
import random

import numpy as np


EPSILON = 1  # exploration rate
MAX_EPSILON = 1
MIN_EPSILON = 0.01
EPSILON_DECAY_RATE = 0.001
ACTIONS = ['UP', 'RIGHT', 'DOWN', "LEFT", 'WAIT', 'BOMB'] # !!!!


def setup(self):

    if self.train:
    #if self.train and not os.path.isfile("q-avoid_stones.pt"):
        pass

    else:
        self.logger.info("Loading model from saved state.")
        with open("q-avoid_stones.pt", "rb") as file:
            self.q = pickle.load(file)

    self.q_dict = {"LEFT": 3, "UP": 0, "RIGHT": 1, "DOWN": 2, "WAIT": 4, "BOMB": 5}


def act(self, game_state: dict) -> str:

    if self.train:
        if game_state['round'] != 1:
            EPSILON1 = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * np.exp(-EPSILON_DECAY_RATE * (game_state['round']-1))
        else: EPSILON1 = EPSILON

        eps_str = "Epsilon = {}".format(EPSILON1)
        self.logger.info(eps_str)

        # todo Exploration vs exploitation
        EPSILON_THRESHOLD = random.uniform(0, 1)
        if EPSILON_THRESHOLD > EPSILON1:
            # choose action with highest value in q-table
            rot = state_to_features(game_state)[1]
            action_rot = np.where(self.q[state_to_features(game_state)[0], :] >= 0)[0]
            best_actions_idx = []
            for x in action_rot:
                a = ACTIONS[(x+rot) % 4]
                best_actions_idx.append(a)

            action = np.random.choice(best_actions_idx)
            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action

        else:
            self.logger.debug("Querying model for action.")
            self.logger.info('Moving with Exploration')
            return np.random.choice(ACTIONS, p = [0.25, 0.25, 0.25, 0.25, 0, 0])

    else:
        if game_state['step'] is None:
            return np.random.choice(ACTIONS, p = [0.25, 0.25, 0.25, 0.25, 0, 0])
        else:
            # choose action with highest value in q-table
            rot = state_to_features(game_state)[1]
            state = state_to_features(game_state)[0]
            action_rot = np.where(self.q[state_to_features(game_state)[0], :] >= 0)[0]
            best_actions_idx = []
            print(self.q[state, :], "rot", rot)
            for x in action_rot:
                a = ACTIONS[(x + rot) % 4]
                best_actions_idx.append(a)

            values_stones = np.zeros(6)

            for i in range(0, 4):
                # values of the q-avoid_stones table
                j = (i + rot) % 4
                action_val = self.q[state, i]
                values_stones[j] = action_val
                # now we have values_stones

            action = np.random.choice(best_actions_idx)
            self.logger.info('Moving with Exploitation')
            self.logger.debug(f'Chosen action {", ".join(map(repr, action))}')
            return action


def state_to_features(game_state: dict) -> np.array:
    # This is the dict before the game begins and after it ends
    if game_state is None:
        return None

    # 4 possibilities for the stones and crates surrounding our agent -> later becoming 6 with crates
    field = game_state["field"]
    agent_pos = game_state["self"][3]

    action_dict = {"RIGHT": (1, 0), "LEFT": (-1, 0), "DOWN": (0, 1), "UP": (0, -1)}

    above = np.array(agent_pos) + np.array(action_dict["UP"])
    below = np.array(agent_pos) + np.array(action_dict["DOWN"])
    right_side = np.array(agent_pos) + np.array(action_dict["RIGHT"])
    left_side = np.array(agent_pos) + np.array(action_dict["LEFT"])

    surrounding = np.array([field[above[0]] [above[1]],field[right_side[0]][right_side[1]],
                           field[below[0]] [below[1]],field[left_side[0]][left_side[1]]])

    # find stone_position
    stone_state, rot = matrix_perm(surrounding)

    channels = []
    channels.append(stone_state)
    channels.append(rot)

    return channels


# find rotation index and state of a matrix (see normed state)
def matrix_perm(matrix):
    locked_ways = np.count_nonzero(np.abs(matrix) == 1)
    # print("locked_ways", locked_ways)
    state = 0
    rot = 0

    # find rotation
    # normed_states = [np.array([0,0,0,0]), np.array([1, 0, 0, 0]), np.array([1, 1, 0, 0]), np.array([0, 1, 1, 1]),
    # np.array([1, 0, 1, 0], np.array([1, 1, 1, 1])
    if locked_ways == 0:
        rot = 0
    elif locked_ways == 1:
        rot = np.where(np.abs(matrix) == 1)[0][0]
        state = 1
    elif locked_ways == 2:
        a, b = np.where(np.abs(matrix) == 1)[0]
        if a == 0 and b == 1:
            rot = 0
            state = 2
        elif a == 1 and b == 2:
            rot = 1
            state = 2
        elif a == 2 and b == 3:
            rot = 2
            state = 2
        elif a == 0 and b == 3:
            rot = 3
            state = 2
        elif a == 0 and b == 2:
            rot = 0
            state = 4
        elif a == 1 and b == 3:
            rot = 1
            state = 4
    elif locked_ways == 3:
        rot = np.where(np.abs(matrix) == 0)[0][0]
        state = 3
    elif state == 4:
        rot = 0
        state = 5

    return state, rot

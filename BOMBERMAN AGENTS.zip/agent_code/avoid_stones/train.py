import pickle
from collections import namedtuple
from typing import List

import events as e
from .callbacks import state_to_features
import numpy as np

GAMMA = 0.9  # discount factor
ALPHA = 0.6  # learning rate


def setup_training(self):
    """
    Initialise self for training purpose.

    This is called after `setup` in callbacks.py.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    """
    # Create Q-List
    self.steps = []
    # self.q_list = []
    if True:
        # if not os.path.isfile("q-model.pt"):
        self.logger.info("Setting up hyperparam")
        self.q = np.zeros((5, 4))

        # a = np.copy(self.q)
        # self.q_list.append(a)

    # create action dictionary for our q list
    self.action = ["UP", "RIGHT", "DOWN", "LEFT", "WAIT", "BOMB"]
    self.q_dict = {"LEFT": 3, "UP": 0, "RIGHT": 1, "DOWN" : 2, "WAIT" : 4, "BOMB": 5}
    self.action_dict = {"RIGHT": (-1, 0), "LEFT": (1, 0), "DOWN": (0, 1), "UP": (0, -1), "WAIT" : (0, 0), "BOMB" : (0, 0)}


def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: List[str]):
    """
    Called once per step to allow intermediate rewards based on game events.

    When this method is called, self.events will contain a list of all game
    events relevant to your agent that occurred during the previous step. Consult
    settings.py to see what events are tracked. You can hand out rewards to your
    agent based on these events and your knowledge of the (new) game state.

    This is one of the places where you could update your agent.

    :param self: This object is passed to all callbacks and you can set arbitrary values.
    :param old_game_state: The state that was passed to the last call of `act`.
    :param self_action: The action that you took.
    :param new_game_state: The state the agent is in now.
    :param events: The events that occurred when going from  `old_game_state` to `new_game_state`
    """

    if old_game_state is None:
        return

    self.logger.debug(f'Encountered game event(s) {", ".join(map(repr, events))} in step {new_game_state["step"]}')

    state = state_to_features(old_game_state)[0]
    rot = state_to_features(old_game_state)[1]
    chosen_action = self_action

    # define rewards
    if old_game_state["self"][3] == new_game_state["self"][3]:
        reward = -1

    else:
        reward = 0
    a = self.q_dict[self.action[(self.q_dict[chosen_action]-rot) % 4]]
    # calculate new q value
    self.q[state, a] = self.q[state, a] * (1 - ALPHA) + ALPHA * (reward + GAMMA *
                                    np.max(self.q[state_to_features(new_game_state)[0], :]))


def end_of_round(self, last_game_state: dict, last_action: str, events: List[str]):
    """
    Called at the end of each game or when the agent died to hand out final rewards.

    This is similar to reward_update. self.events will contain all events that
    occurred during your agent's final step.

    This is one of the places where you could update your agent.
    This is also a good place to store an agent that you updated.

    :param self: The same object that is passed to all of your callbacks.
    """
    self.logger.debug(f'Encountered event(s) {", ".join(map(repr, events))} in final step')

    # Store the model
    with open("q-avoid_stones.pt", "wb") as file:
        pickle.dump(self.q, file)

    # track the steps of each round
    self.steps.append(last_game_state['step'])
    with open('steps_needed.pt', 'wb') as file:
        pickle.dump(self.steps, file)

    a = np.copy(self.q)
    # self.q_list.append(a)
    # if last_game_state["round"] == 2:
    # with open('q_list.pt', 'wb') as file:
    #    pickle.dump(self.q_list, file)

    # print round
    rounds = 'Runde: {}'.format(last_game_state['round'])
    self.logger.info(rounds)